# Documento de diseño: *América 1000-1490, imperios antes de Colón*

## 1. Concepto

Juego educativo de estrategia por turnos con dados, de estética 8 bits, inspirado en la mecánica de RISK pero
construido sobre la historia real de los pueblos americanos entre el año 1000 y 1490 d.C. El jugador elige uno de los
pueblos existentes en el año 1000 y lo guía durante 50 turnos (10 años por turno) mientras 47 pueblos más, controlados
por la computadora, se expanden, colapsan o surgen según una línea de tiempo de 64 eventos fechados.

Principios de diseño:

- **Fidelidad concisa**: cada pueblo se describe en una ficha de nueve campos (periodo, capital, población, lengua,
  gobierno, economía, guerra, logro, curiosidad). Las cifras de población son rangos de estimaciones académicas.
- **La capacidad histórica se traduce en reglas**: rasgos de ataque, defensa, producción, terreno favorable, navegación
  y caminos, más un *potencial por siglo* (0-7) que refleja el auge o declive real de cada pueblo.
- **Mapas que cambian**: las fronteras se redibujan con cada conquista o colapso. Al inicio de cada siglo (1100, 1200,
  1300, 1400) y en 1490 se guarda un mapa de era en el Atlas y como imagen PNG. Son los "5 mapas cada 100 años".
- **El jugador puede torcer la historia**: los eventos que condenan a un pueblo (caída de Tula, colapso de Tiwanaku,
  abandono de Cahokia) no eliminan al jugador: le quitan la mitad de sus ejércitos y le dejan resistir.
- **Sin dependencias externas**: el juego corre desde un único ejecutable (PyInstaller). La única biblioteca es pygame,
  empaquetada dentro del ejecutable. No hay conexión a internet ni archivos de datos sueltos: el mapa, las fichas y los
  eventos van embebidos en el código.

## 2. Mapa

- Rejilla de 268 x 256 celdas de 0,5 grados (lon -168 a -34, lat -56 a 72), rasterizada a partir del contorno de
  Natural Earth (dominio público) por `tools/rasterize.py` y guardada en `game/landmask.py`.
- 176 provincias definidas por una semilla geográfica (lat/lon), nombre, terreno y pueblos históricos
  (`game/provincias.py`). Cada provincia crece desde su semilla sobre las celdas de tierra (algoritmo de Dijkstra con
  ruido), lo que garantiza regiones contiguas y fronteras orgánicas.
- 58 rutas marítimas históricas (Caribe, costa del Pacífico, Amazonas, Ártico) conectan provincias no contiguas.
- Cinco niveles de zoom (3 a 12 píxeles por celda), desplazamiento con el ratón y centrado en la capital.

## 3. Turno

1. **Refuerzos** = 1 + provincias/3 (hasta la capacidad administrativa) + producción + potencial del siglo.
   Capacidad administrativa = 3 + 4 x potencial. Ejércitos enormes (más de 5 x capacidad + 10) reciben la mitad de
   refuerzos (desgaste logístico) y ninguna provincia supera 60 ejércitos.
2. **Ataque**: atacante hasta 3 dados (deja 1 ejército atrás), defensor hasta 2. Se ordenan y comparan por pares; el
   empate favorece al defensor. Al dado más alto de cada bando se suman modificadores. Se puede atacar tantas veces
   como se quiera.
3. **Movimiento**: un único traslado entre provincias propias conectadas (a dos saltos si el pueblo tiene caminos).

Modificadores: ataque del pueblo (0-2), defensa del pueblo (0-3), +1 si el defensor está en su terreno favorable,
+2 en su capital (+1 más si es su último reducto), +1 en sus provincias natales, +1 en selva, montaña o altiplano
neutrales, -1 al atacar por mar sin ser pueblo navegante.

## 4. Inteligencia artificial

Cada pueblo de la IA refuerza sus fronteras más amenazadas, ataca solo objetivos dentro de su *alcance* (1 + potencial
saltos desde la capital) y con una ventaja mínima que depende de su agresividad histórica (0,15 los taínos, 0,95 los
mexicas tras 1428 o los incas tras 1438). Prefiere tierras neutrales a otros pueblos y evita atacar capitales bien
defendidas. Al superar su capacidad administrativa deja de expandirse. Así, en partidas simuladas sin jugador los incas
terminan primeros en más del 90 % de los casos, los mexicas dominan el centro de México y pueblos como taínos, muiscas o
mapuches sobreviven casi siempre, mientras Tula, Wari, Tiwanaku, Cahokia, Mayapán y los hohokam desaparecen en las
fechas reales.

## 5. Eras y eventos

Los 64 eventos de `game/eventos.py` se disparan en el turno que cubre su año. Cada uno muestra un cuadro con
explicación histórica y aplica efectos sobre el mapa: refuerzo, boost, debilitar, colapso, perder/ganar provincia,
nueva facción, renombrar, cambiar rasgo, anexión y sequía. Al comenzar cada siglo se muestra el balance de la era
(quién creció, quién desapareció, quién surgió) y se guarda el mapa.

## 6. Fin de partida

En 1490, justo antes de la llegada de Colón, se muestra el ranking final, la comparación con lo que dice la historia
sobre el pueblo del jugador y la lista de pueblos desaparecidos con su fecha. Si el jugador pierde su última provincia,
la partida termina como derrota.

## 7. Pueblos jugables y de la IA

| Pueblo | Aparece | Capital | Rasgos | Potencial 1000/1100/1200/1300/1400 |
|---|---|---|---|---|
| Inuit (cultura Thule) | 1000 | alaska_n | defensa +1, tundra, navegantes | 1/2/2/2/1 |
| Pueblos de la Costa Noroeste | 1000 | haida | ataque +1, producción +1, costa, navegantes | 1/1/1/1/1 |
| Cahokia (Misisipianos) | 1000 | cahokia | producción +2, llanura | 3/3/2/0/0 |
| Moundville y Etowah | 1000 | moundville | defensa +1, producción +1, bosque | 1/2/2/2/1 |
| Caddo (Spiro) | 1000 | spiro | producción +1, bosque | 1/1/1/1/0 |
| Pueblo Ancestrales | 1000 | chaco | defensa +1, producción +1, desierto | 2/2/1/1/1 |
| Hohokam | 1000 | hohokam | producción +2, desierto | 1/1/1/1/0 |
| Paquimé (Casas Grandes) | 1130 | paquime | defensa +1, producción +1, desierto | 0/1/2/2/0 |
| Haudenosaunee (Iroqueses) | 1000 | iroquois | ataque +1, producción +1, bosque | 1/1/1/2/2 |
| Calusa | 1000 | calusa | defensa +1, costa, navegantes | 1/1/1/1/1 |
| Chichimecas | 1000 | chichimeca | ataque +1, desierto | 1/2/2/1/1 |
| Toltecas | 1000 | tula | ataque +1, producción +1, llanura | 4/3/0/0/0 |
| Mexicas (migrantes de Aztlán) | 1000 | aztlan | ataque +1, defensa +1, altiplano | 0/0/1/2/6 |
| Purépechas (Tarascos) | 1000 | michoacan | defensa +2, producción +1, altiplano | 1/1/2/3/4 |
| Mixtecos | 1000 | mixteca | defensa +1, producción +1, montaña | 2/2/2/2/2 |
| Zapotecas | 1000 | oaxaca | defensa +1, producción +1, altiplano | 2/2/2/2/2 |
| Totonacas | 1000 | totonac | producción +2, costa | 2/1/1/1/1 |
| Huastecos | 1000 | huasteca | defensa +1, producción +1, costa | 1/1/1/1/1 |
| Tlaxcaltecas | 1348 | tlaxcala | ataque +1, defensa +2, altiplano | 0/0/0/2/3 |
| Mayas itzáes (Chichén Itzá) | 1000 | chichen | ataque +1, producción +1, selva, navegantes | 4/3/3/3/1 |
| Mayas k'iche' | 1225 | quiche | ataque +1, defensa +1, montaña | 0/0/2/3/4 |
| Mayas kaqchikeles | 1470 | kaqchikel | ataque +1, defensa +1, montaña | 0/0/0/0/2 |
| Chorotegas y nicaraos | 1000 | nicaragua | producción +1, llanura | 1/1/2/2/2 |
| Pipiles (Cuzcatlán) | 1000 | salvador | ataque +1, costa | 1/1/1/1/1 |
| Taínos | 1000 | quisqueya | producción +2, isla, navegantes | 2/2/3/3/3 |
| Kalinago (Caribes) | 1200 | antillas_s | ataque +1, isla, navegantes | 0/0/1/2/2 |
| Tairona | 1000 | tairona | defensa +2, producción +1, montaña | 2/2/2/2/2 |
| Zenúes | 1000 | zenu | producción +2, llanura | 2/1/1/1/1 |
| Quimbayas | 1000 | quimbaya | defensa +1, producción +1, montaña | 1/1/1/1/1 |
| Muiscas | 1000 | muisca_s | defensa +1, producción +2, altiplano | 2/2/2/3/3 |
| Caranquis y quitus | 1000 | quito | defensa +2, montaña | 1/1/1/1/1 |
| Manteños | 1000 | manteno | producción +2, costa, navegantes | 1/1/1/1/1 |
| Cañaris | 1000 | canari | defensa +2, montaña | 1/1/1/1/1 |
| Chachapoyas | 1000 | chachapoyas | defensa +2, montaña | 1/1/1/1/1 |
| Sicán (Lambayeque) | 1000 | lambayeque | producción +2, costa | 3/2/2/1/0 |
| Chimú | 1000 | chanchan | ataque +1, defensa +1, producción +1, costa | 3/3/4/4/3 |
| Chinchas | 1000 | chincha | producción +2, costa, navegantes | 1/2/2/2/2 |
| Wari (Huari) | 1000 | huari | ataque +1, producción +1, montaña, caminos | 2/0/0/0/0 |
| Chancas | 1300 | huari | ataque +2, montaña | 0/0/0/3/3 |
| Cusco (Killke, preinca) | 1000 | cusco | defensa +1, producción +1, montaña, caminos | 1/1/2/2/7 |
| Tiwanaku | 1000 | tiwanaku | defensa +1, producción +1, altiplano | 2/0/0/0/0 |
| Reinos aymaras (Colla y Lupaqa) | 1100 | titicaca | ataque +1, defensa +1, altiplano | 0/2/2/2/1 |
| Diaguitas | 1000 | diaguita | defensa +2, montaña | 1/1/1/1/1 |
| Mapuches | 1000 | mapuche | ataque +1, defensa +2, bosque | 1/1/1/1/2 |
| Guaraníes | 1000 | guarani | ataque +1, selva, caminos | 1/2/2/2/2 |
| Tupinambás | 1000 | bahia | ataque +1, costa, navegantes, caminos | 1/1/2/2/3 |
| Marajoara | 1000 | marajo | producción +2, isla, navegantes | 2/1/1/0/0 |
| Tapajós (Santarém) | 1000 | tapajos | defensa +1, producción +1, selva, navegantes | 1/1/1/1/1 |

## 8. Línea de tiempo

| Año | Evento | Pueblo | Efecto en el juego |
|---|---|---|---|
| 1000 | Apogeo de Tula | toltecas | boost toltecas |
| 1000 | Los vikingos llegan a Vinlandia | - | narrativo |
| 1000 | Sequía en el altiplano andino | tiwanaku | debilitar tiwanaku |
| 1000 | Chichén Itzá, capital del norte maya | mayas_yuc | boost mayas_yuc |
| 1000 | Sicán Medio: auge de Batán Grande | sican | boost sican |
| 1000 | Los thule cruzan Alaska | thule | refuerzo thule |
| 1050 | El 'Big Bang' de Cahokia | cahokia | boost cahokia; rasgo cahokia |
| 1050 | Decadencia de Wari | wari | debilitar wari; perder wari |
| 1060 | Comercio Chaco-Mesoamérica | pueblo | boost pueblo |
| 1063 | 8 Venado Garra de Jaguar | mixtecos | boost mixtecos; rasgo mixtecos; rasgo mixtecos |
| 1100 | Colapso de Wari | wari | colapso wari |
| 1100 | Fin de Tiwanaku y reinos aymaras | aymaras | colapso tiwanaku; nueva aymaras |
| 1100 | Teyuna, la Ciudad Perdida | tairona | boost tairona |
| 1100 | Chincha, señores del mar | chinchas | boost chinchas |
| 1115 | Muerte de 8 Venado | mixtecos | rasgo mixtecos; rasgo mixtecos |
| 1130 | Gran sequía del Chaco | pueblo | perder pueblo; sequia ['chaco', 'rio_grande', 'hohokam'] |
| 1130 | Fundación de Paquimé | paquime | nueva paquime |
| 1142 | La Gran Ley de la Paz | haudenosaunee | boost haudenosaunee; rasgo haudenosaunee |
| 1150 | Caída de Tula | toltecas | colapso toltecas; ganar chichimecas |
| 1150 | Incendio de Batán Grande | sican | debilitar sican |
| 1168 | Los mexicas dejan Aztlán | mexicas | refuerzo mexicas; rasgo mexicas |
| 1175 | Xólotl y los chichimecas en el Valle de México | chichimecas | ganar chichimecas; boost chichimecas |
| 1200 | Manco Cápac funda el Cusco | incas | renombrar incas; boost incas |
| 1200 | Auge de Chan Chan | chimu | boost chimu; rasgo chimu |
| 1200 | Abandono de El Tajín | totonacas | debilitar totonacas |
| 1200 | Declive de Chichén Itzá | mayas_yuc | debilitar mayas_yuc |
| 1200 | Los kalinago llegan a las Antillas | kalinago | nueva kalinago |
| 1200 | Apogeo de Spiro | caddo | boost caddo |
| 1221 | Mayapán, capital de la Liga | mayas_yuc | renombrar mayas_yuc; ganar mayas_yuc |
| 1225 | Fundación de Q'umarkaj | quiches | nueva quiches |
| 1250 | Viviendas en los acantilados | pueblo | rasgo pueblo |
| 1250 | Los mexicas en el Valle de México | mexicas | perder mexicas; ganar mexicas |
| 1250 | Etowah en su apogeo | moundville | boost moundville |
| 1276 | La Gran Sequía (1276-1299) | pueblo | perder pueblo; ganar pueblo; renombrar pueblo; sequia ['hohokam', 'chaco', 'mesa_verde'] |
| 1300 | Los chancas | chancas | nueva chancas |
| 1300 | Cahokia se vacía | cahokia | debilitar cahokia; rasgo cahokia |
| 1300 | Kuélap, fortaleza en las nubes | chachapoyas | boost chachapoyas |
| 1300 | Expansión guaraní | guaranies | boost guaranies |
| 1325 | Fundación de Tenochtitlan | mexicas | renombrar mexicas; ganar mexicas; rasgo mexicas |
| 1348 | Fundación de Tlaxcala | tlaxcaltecas | nueva tlaxcaltecas |
| 1350 | Abandono de Cahokia | cahokia | colapso cahokia |
| 1350 | Tariácuri unifica a los purépechas | purepechas | boost purepechas; rasgo purepechas; ganar purepechas |
| 1350 | Decadencia de Marajó | marajoara | debilitar marajoara |
| 1375 | Chimú conquista Lambayeque | chimu | anexion chimu |
| 1400 | Desaparición de los dorset | thule | ganar thule; ganar thule; ganar thule |
| 1400 | Fin de Marajó | marajoara | colapso marajoara |
| 1400 | Los tupinambás dominan la costa | tupinambas | boost tupinambas; ganar tupinambas |
| 1410 | Moundville declina | moundville | debilitar moundville |
| 1428 | La Triple Alianza | mexicas | boost mexicas; rasgo mexicas; rasgo mexicas; ganar mexicas; ganar mexicas |
| 1438 | Pachacuti y el nacimiento del Tahuantinsuyo | incas | anexion incas; boost incas; renombrar incas; rasgo incas; rasgo incas; rasgo incas |
| 1441 | Caída de Mayapán | mayas_yuc | colapso mayas_yuc |
| 1450 | Los hohokam abandonan sus canales | hohokam | colapso hohokam; colapso paquime |
| 1450 | Zipa y Zaque | muiscas | boost muiscas |
| 1458 | Moctezuma I conquista Coixtlahuaca | mexicas | ganar mexicas |
| 1463 | Túpac Yupanqui somete a los collas | incas | anexion incas |
| 1470 | Los incas conquistan Chimor | incas | anexion incas; anexion incas |
| 1470 | Los kaqchikeles fundan Iximché | kaqchikeles | nueva kaqchikeles |
| 1476 | Chincha se somete al inca | incas | anexion incas |
| 1478 | Guerra mexica-purépecha | purepechas | boost purepechas; rasgo purepechas |
| 1480 | Túpac Yupanqui en el sur | incas | anexion incas; anexion incas; ganar incas; ganar incas |
| 1485 | Batalla del Maule | mapuches | boost mapuches; rasgo mapuches |
| 1486 | Ahuízotl expande el imperio | mexicas | ganar mexicas; ganar mexicas; ganar mexicas; boost mexicas |
| 1487 | Consagración del Templo Mayor | mexicas | narrativo |
| 1490 | Vísperas del encuentro | - | narrativo |

## 9. Fuentes generales

Las fichas resumen consensos de manuales y obras de referencia: *The Cambridge History of the Native Peoples of the
Americas*; Michael D. Coe, *Mexico* y *The Maya*; Michael Moseley, *The Incas and Their Ancestors*; Timothy Pauketat,
*Cahokia*; Charles Mann, *1491*; Alfredo López Austin y Leonardo López Luján, *El pasado indígena*; María Rostworowski,
*Historia del Tahuantinsuyu*; Irving Rouse, *The Tainos*; y las publicaciones del ICANH (Colombia) sobre muiscas,
taironas y zenúes. Las fechas tradicionales (fundación de Cusco, salida de Aztlán, Liga Haudenosaunee) se marcan como
tales en los textos del juego.

## 10. Cómo ampliar el juego

- **Nuevo pueblo**: añadir una entrada en `FACCIONES` y su potencial en `POTENCIAL` (`game/facciones.py`).
- **Nueva provincia**: añadir una tupla en `PROVINCIAS` (`game/provincias.py`); el mapa se regenera solo.
- **Nuevo evento**: añadir un diccionario en `EVENTOS` (`game/eventos.py`) con año, título, texto y efectos.
- El script `tools/rasterize.py` solo hace falta si se quiere cambiar la resolución o el recorte del mapa.
