# -*- coding: utf-8 -*-
"""Construcción del mapa: celdas de tierra -> provincias contiguas + adyacencias."""
import heapq, random
from .landmask import LON0, LAT1, COLS, ROWS, STEP, MASK
from .provincias import PROVINCIAS, CONEXIONES_MAR


def geo_a_celda(lat, lon):
    c = int((lon - LON0) / STEP)
    r = int((LAT1 - lat) / STEP)
    return max(0, min(COLS - 1, c)), max(0, min(ROWS - 1, r))


class Mapa:
    def __init__(self, semilla=7):
        self.cols, self.rows = COLS, ROWS
        self.tierra = [[MASK[r][c] == "#" for c in range(COLS)] for r in range(ROWS)]
        self.prov_de_celda = [[-1] * COLS for _ in range(ROWS)]
        self.provincias = []          # lista de dicts
        self.indice = {}              # id -> índice
        self._construir(semilla)

    # ------------------------------------------------------------
    def _celda_tierra_cercana(self, c, r):
        if self.tierra[r][c]:
            return c, r
        mejor, bd = None, 1e9
        for rr in range(max(0, r - 6), min(ROWS, r + 7)):
            for cc in range(max(0, c - 6), min(COLS, c + 7)):
                if self.tierra[rr][cc]:
                    d = (rr - r) ** 2 + (cc - c) ** 2
                    if d < bd:
                        bd, mejor = d, (cc, rr)
        if mejor is None:
            raise ValueError(f"Semilla sin tierra cerca: {c},{r}")
        return mejor

    def _construir(self, semilla):
        rng = random.Random(semilla)
        # ruido por celda para fronteras orgánicas
        ruido = [[rng.random() * 0.9 for _ in range(COLS)] for _ in range(ROWS)]
        heap = []
        for i, (pid, nombre, lat, lon, terreno, pueblos) in enumerate(PROVINCIAS):
            c, r = geo_a_celda(lat, lon)
            c, r = self._celda_tierra_cercana(c, r)
            self.provincias.append(dict(id=pid, nombre=nombre, lat=lat, lon=lon, terreno=terreno,
                                        pueblos=pueblos, semilla=(c, r), celdas=[], vecinos=set()))
            self.indice[pid] = i
            heapq.heappush(heap, (0.0, i, c, r))
        dist = [[1e9] * COLS for _ in range(ROWS)]
        while heap:
            d, i, c, r = heapq.heappop(heap)
            if self.prov_de_celda[r][c] != -1:
                continue
            self.prov_de_celda[r][c] = i
            self.provincias[i]["celdas"].append((c, r))
            for dc, dr in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                cc, rr = c + dc, r + dr
                if 0 <= cc < COLS and 0 <= rr < ROWS and self.tierra[rr][cc] and self.prov_de_celda[rr][cc] == -1:
                    # el coste crece con la latitud (celdas más pequeñas al norte) y con el ruido
                    nd = d + 1.0 + ruido[rr][cc]
                    if nd < dist[rr][cc]:
                        dist[rr][cc] = nd
                        heapq.heappush(heap, (nd, i, cc, rr))
        # islas sin semilla cercana (no alcanzadas): asignar a provincia más cercana en línea recta
        for r in range(ROWS):
            for c in range(COLS):
                if self.tierra[r][c] and self.prov_de_celda[r][c] == -1:
                    mejor = min(range(len(self.provincias)),
                                key=lambda i: (self.provincias[i]["semilla"][0] - c) ** 2 + (self.provincias[i]["semilla"][1] - r) ** 2)
                    self.prov_de_celda[r][c] = mejor
                    self.provincias[mejor]["celdas"].append((c, r))
        # adyacencias por tierra
        for r in range(ROWS):
            for c in range(COLS):
                a = self.prov_de_celda[r][c]
                if a < 0:
                    continue
                for dc, dr in ((1, 0), (0, 1)):
                    cc, rr = c + dc, r + dr
                    if cc < COLS and rr < ROWS:
                        b = self.prov_de_celda[rr][cc]
                        if b >= 0 and b != a:
                            self.provincias[a]["vecinos"].add(b)
                            self.provincias[b]["vecinos"].add(a)
        # adyacencias marítimas
        self.rutas_mar = []
        for x, y in CONEXIONES_MAR:
            a, b = self.indice[x], self.indice[y]
            if b not in self.provincias[a]["vecinos"]:
                self.rutas_mar.append((a, b))
            self.provincias[a]["vecinos"].add(b)
            self.provincias[b]["vecinos"].add(a)
        # centro visual (celda más "interior")
        for p in self.provincias:
            cs = p["celdas"]
            mc = sum(c for c, _ in cs) / len(cs)
            mr = sum(r for _, r in cs) / len(cs)
            # elegir la celda de la provincia más cercana al centroide
            p["centro"] = min(cs, key=lambda x: (x[0] - mc) ** 2 + (x[1] - mr) ** 2)
            p["vecinos"] = sorted(p["vecinos"])

    def idx(self, pid):
        return self.indice[pid]
