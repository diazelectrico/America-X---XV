# -*- coding: utf-8 -*-
"""Motor del juego: estado, turnos, combate con dados, IA, eventos históricos y eras."""
import copy, json, random
from .mapa import Mapa
from .facciones import FACCIONES, POTENCIAL
from .eventos import EVENTOS, ERAS, AÑO_FINAL, AÑOS_POR_TURNO

NEUTRAL = None
FUERZA_NEUTRAL = dict(tundra=1, taiga=2, desierto=2, llanura=3, bosque=3, costa=3, isla=2,
                      selva=4, montaña=4, altiplano=4)


class Faccion:
    def __init__(self, d):
        self.id = d["id"]
        self.nombre = d["nombre"]
        self.nombre_original = d["nombre"]
        self.color = tuple(d["color"])
        self.capital = d["capital"]
        self.provincias_iniciales = list(d["provincias"])
        self.unidades_iniciales = d["unidades"]
        self.inicio = d["inicio"]
        self.rasgos = dict(d["rasgos"])
        self.ficha = dict(d["ficha"])
        self.viva = d["inicio"] <= 1000
        self.aparecio = self.viva
        self.es_jugador = False
        self.conquistas = 0
        self.eliminada_en = None
        self.eliminada_por = None
        self.max_provincias = 0
        self.potencial = POTENCIAL.get(self.id, [1, 1, 1, 1, 1])

    def a_dict(self):
        return dict(id=self.id, nombre=self.nombre, capital=self.capital, rasgos=self.rasgos, viva=self.viva,
                    aparecio=self.aparecio, es_jugador=self.es_jugador, conquistas=self.conquistas,
                    eliminada_en=self.eliminada_en, eliminada_por=self.eliminada_por, max_provincias=self.max_provincias)

    def de_dict(self, d):
        for k, v in d.items():
            setattr(self, k, v)
        self.rasgos = dict(self.rasgos)


class ResultadoAtaque:
    def __init__(self):
        self.dados_ataque = []
        self.dados_defensa = []
        self.mod_ataque = 0
        self.mod_defensa = 0
        self.perdidas_ataque = 0
        self.perdidas_defensa = 0
        self.conquista = False
        self.eliminada = None   # id de facción eliminada
        self.detalle = ""


class Juego:
    def __init__(self, jugador_id=None, semilla=None):
        self.semilla = semilla if semilla is not None else random.randrange(1 << 30)
        self.rng = random.Random(self.semilla)
        self.mapa = Mapa(7)
        self.n = len(self.mapa.provincias)
        self.facciones = {d["id"]: Faccion(d) for d in FACCIONES}
        self.orden = [d["id"] for d in FACCIONES]
        self.dueño = [NEUTRAL] * self.n
        self.unidades = [0] * self.n
        self.año = 1000
        self.turno = 1
        self.jugador = jugador_id
        self.fase = "refuerzo"
        self.refuerzos = 0
        self.fortificado = False
        self.conquisto_este_turno = False
        self.log = []               # (año, texto, color)
        self.cola_eventos = []      # eventos históricos para mostrar en pantalla
        self.mapas_era = {}         # año -> (dueño[], unidades[], resumen)
        self.balance_era = []       # textos de resumen de la era que acaba
        self.terminado = False
        self.resultado = None
        self.eventos_disparados = set()
        self._inicializar()

    # ------------------------------------------------------------ inicio
    def _inicializar(self):
        for i, p in enumerate(self.mapa.provincias):
            self.unidades[i] = FUERZA_NEUTRAL.get(p["terreno"], 2)
        for f in self.facciones.values():
            if f.viva:
                self._asentar(f)
        if self.jugador:
            self.facciones[self.jugador].es_jugador = True
        self._guardar_mapa_era(1000)
        self.refuerzos = self.calcular_refuerzos(self.jugador) if self.jugador else 0
        self._disparar_eventos()

    def _asentar(self, f, provincias=None, unidades=None):
        provs = provincias or f.provincias_iniciales
        total = unidades or f.unidades_iniciales
        provs = [p for p in provs if p in self.mapa.indice]
        if not provs:
            return
        # si es una facción que aparece en medio de la partida y el jugador posee la provincia, busca otra libre
        libres = []
        for pid in provs:
            i = self.mapa.idx(pid)
            if self.dueño[i] is not None and self.facciones[self.dueño[i]].es_jugador:
                continue
            libres.append(i)
        if not libres:
            cand = [v for pid in provs for v in self.mapa.provincias[self.mapa.idx(pid)]["vecinos"]
                    if self.dueño[v] is None or not self.facciones[self.dueño[v]].es_jugador]
            if not cand:
                return
            libres = [cand[0]]
        cap = self.mapa.idx(f.capital) if f.capital in self.mapa.indice else libres[0]
        if cap not in libres:
            cap = libres[0]
        por_prov = max(1, total // len(libres))
        for i in libres:
            self._quitar_dueño(i)
            self.dueño[i] = f.id
            self.unidades[i] = por_prov
        self.unidades[cap] += total - por_prov * len(libres) + 1
        f.viva = True
        f.aparecio = True

    def _quitar_dueño(self, i):
        self.dueño[i] = NEUTRAL

    # ------------------------------------------------------------ consultas
    def provincias_de(self, fid):
        return [i for i in range(self.n) if self.dueño[i] == fid]

    def facciones_vivas(self):
        return [f for f in self.facciones.values() if f.viva]

    def calcular_refuerzos(self, fid):
        if not fid:
            return 0
        f = self.facciones[fid]
        n = len(self.provincias_de(fid))
        if n == 0:
            return 0
        pot = self.potencial_actual(fid)
        cap = self.capacidad(fid)
        n_eff = min(n, cap)
        r = 1 + n_eff // 3 + f.rasgos.get("produccion", 0) + pot
        # desgaste logístico: ejércitos enormes cuestan mantenerse
        if self.poder(fid) > 5 * cap + 10:
            r = max(1, r // 2)
        return r

    def capacidad(self, fid):
        """Número de provincias que la facción puede administrar con eficacia en esta era."""
        return 3 + 4 * self.potencial_actual(fid)

    def bono_defensa(self, destino):
        """Bonificación total de defensa que recibiría la provincia destino."""
        pd = self.mapa.provincias[destino]
        d = self.dueño[destino]
        if d is None:
            return 1 if pd["terreno"] in ("montaña", "selva", "altiplano") else 0
        f = self.facciones[d]
        md = f.rasgos.get("defensa", 0)
        if f.rasgos.get("terreno") == pd["terreno"]:
            md += 1
        if f.capital == pd["id"]:
            md += 2
            if len(self.provincias_de(d)) == 1:
                md += 1          # último reducto
        elif pd["id"] in f.provincias_iniciales:
            md += 1
        return md

    def era_indice(self):
        return max(0, min(4, (self.año - 1000) // 100))

    def potencial_actual(self, fid):
        return self.facciones[fid].potencial[self.era_indice()]

    def distancias_desde(self, i):
        """Distancia en saltos desde la provincia i a todas las demás."""
        dist = {i: 0}
        frontera = [i]
        while frontera:
            nueva = []
            for a in frontera:
                for v in self.mapa.provincias[a]["vecinos"]:
                    if v not in dist:
                        dist[v] = dist[a] + 1
                        nueva.append(v)
            frontera = nueva
        return dist

    def poder(self, fid):
        return sum(self.unidades[i] for i in self.provincias_de(fid))

    def es_ruta_mar(self, a, b):
        return (a, b) in self.mapa.rutas_mar or (b, a) in self.mapa.rutas_mar

    def puede_atacar(self, fid, origen, destino):
        if self.dueño[origen] != fid or self.dueño[destino] == fid:
            return False
        if destino not in self.mapa.provincias[origen]["vecinos"]:
            return False
        return self.unidades[origen] >= 2

    def alcanzables_para_mover(self, fid, origen):
        """Provincias propias a distancia 1 (o 2 con movilidad) a través de territorio propio."""
        f = self.facciones[fid]
        prof = 2 if f.rasgos.get("movilidad") else 1
        vistos = {origen}
        frontera = [origen]
        for _ in range(prof):
            nueva = []
            for a in frontera:
                for v in self.mapa.provincias[a]["vecinos"]:
                    if v not in vistos and self.dueño[v] == fid:
                        vistos.add(v)
                        nueva.append(v)
            frontera = nueva
        vistos.discard(origen)
        return sorted(vistos)

    # ------------------------------------------------------------ acciones del turno
    def colocar_refuerzo(self, i, n=1):
        if self.fase != "refuerzo" or self.dueño[i] != self.jugador or self.refuerzos < n:
            return False
        self.unidades[i] += n
        self.refuerzos -= n
        return True

    def pasar_fase(self):
        if self.fase == "refuerzo":
            if self.refuerzos > 0:
                # refuerzos sin colocar van a la capital o primera provincia
                provs = self.provincias_de(self.jugador)
                if provs:
                    cap = self.mapa.idx(self.facciones[self.jugador].capital)
                    dest = cap if cap in provs else provs[0]
                    self.unidades[dest] += self.refuerzos
                self.refuerzos = 0
            self.fase = "ataque"
        elif self.fase == "ataque":
            self.fase = "movimiento"
        elif self.fase == "movimiento":
            self.terminar_turno()

    def fortificar(self, origen, destino, n):
        if self.fase != "movimiento" or self.fortificado:
            return False
        if self.dueño[origen] != self.jugador or destino not in self.alcanzables_para_mover(self.jugador, origen):
            return False
        n = min(n, self.unidades[origen] - 1)
        if n <= 0:
            return False
        self.unidades[origen] -= n
        self.unidades[destino] += n
        self.fortificado = True
        return True

    # ------------------------------------------------------------ combate
    def _tirar(self, k):
        return sorted((self.rng.randint(1, 6) for _ in range(k)), reverse=True)

    def atacar(self, origen, destino, fid=None):
        fid = fid or self.dueño[origen]
        res = ResultadoAtaque()
        if not self.puede_atacar(fid, origen, destino):
            res.detalle = "Ataque no válido"
            return res
        atacante = self.facciones[fid]
        defensor_id = self.dueño[destino]
        defensor = self.facciones[defensor_id] if defensor_id else None
        pd = self.mapa.provincias[destino]
        na = min(3, self.unidades[origen] - 1)
        nd = min(2, self.unidades[destino])
        res.dados_ataque = self._tirar(na)
        res.dados_defensa = self._tirar(nd)
        # modificadores
        ma = atacante.rasgos.get("ataque", 0)
        if self.es_ruta_mar(origen, destino) and not atacante.rasgos.get("naval"):
            ma -= 1
        md = self.bono_defensa(destino)
        res.mod_ataque, res.mod_defensa = ma, md
        a = list(res.dados_ataque)
        d = list(res.dados_defensa)
        a[0] += ma
        d[0] += md
        for x, y in zip(a, d):
            if x > y:
                res.perdidas_defensa += 1
            else:
                res.perdidas_ataque += 1
        self.unidades[origen] -= res.perdidas_ataque
        self.unidades[destino] -= res.perdidas_defensa
        if self.unidades[destino] <= 0:
            res.conquista = True
            mover = self.unidades[origen] - 1
            self.unidades[destino] = mover
            self.unidades[origen] = 1
            self.dueño[destino] = fid
            atacante.conquistas += 1
            if fid == self.jugador:
                self.conquisto_este_turno = True
            if defensor and not self.provincias_de(defensor_id):
                defensor.viva = False
                defensor.eliminada_en = self.año
                defensor.eliminada_por = fid
                res.eliminada = defensor_id
                self.registrar(f"{defensor.nombre} desaparece de la historia, sometidos por {atacante.nombre}.", atacante.color)
                if defensor.es_jugador:
                    self.terminado = True
                    self.resultado = "derrota"
            if defensor and defensor.capital == pd["id"]:
                self.registrar(f"{atacante.nombre} toma {pd['nombre']}, capital de {defensor.nombre}.", atacante.color)
        return res

    # ------------------------------------------------------------ IA
    def _amenaza(self, i, fid):
        return sum(self.unidades[v] for v in self.mapa.provincias[i]["vecinos"] if self.dueño[v] != fid)

    def turno_ia(self, fid):
        f = self.facciones[fid]
        provs = self.provincias_de(fid)
        if not provs:
            f.viva = False
            f.eliminada_en = f.eliminada_en or self.año
            f.eliminada_por = f.eliminada_por or "historia"
            return
        agr = f.rasgos.get("agresividad", 0.4)
        # refuerzos: a las provincias fronterizas más amenazadas, con algo de azar
        ref = self.calcular_refuerzos(fid)
        frontera = [i for i in provs if any(self.dueño[v] != fid for v in self.mapa.provincias[i]["vecinos"])]
        if not frontera:
            frontera = provs
        while ref > 0:
            if self.rng.random() < 0.7:
                dest = max(frontera, key=lambda i: self._amenaza(i, fid) - self.unidades[i] + self.rng.random() * 3)
            else:
                dest = self.rng.choice(frontera)
            self.unidades[dest] += 1
            ref -= 1
        # ataques: limitados por el alcance histórico (saltos desde la capital)
        pot = self.potencial_actual(fid)
        agr = agr * min(1.0, 0.4 + pot * 0.25)
        cap = self.mapa.idx(f.capital)
        if self.dueño[cap] != fid:
            cap = provs[0]
        dist = self.distancias_desde(cap)
        alcance = max(2, 1 + pot)
        capacidad = self.capacidad(fid)
        n_provs = len(provs)
        ataques = 0
        max_ataques = 1 + pot + int(agr * 3)
        intentos = 0
        while ataques < max_ataques and intentos < 40:
            intentos += 1
            candidatos = []
            for i in self.provincias_de(fid):
                if self.unidades[i] < 3:
                    continue
                for v in self.mapa.provincias[i]["vecinos"]:
                    if self.dueño[v] == fid or dist.get(v, 99) > alcance:
                        continue
                    ratio = self.unidades[i] / (max(1, self.unidades[v]) * (1 + 0.35 * self.bono_defensa(v)))
                    obj = self.facciones[self.dueño[v]] if self.dueño[v] else None
                    umbral = 1.8 if obj is None else 2.3 - agr * 0.6
                    if n_provs >= capacidad:
                        umbral += 1.0
                    if ratio < umbral:
                        continue
                    prioridad = ratio + (0.5 if obj is None else 0.0) - dist.get(v, 0) * 0.1
                    if obj and obj.es_jugador:
                        prioridad += 0.3 * agr
                    candidatos.append((prioridad, i, v))
            if not candidatos or self.rng.random() > agr + 0.2:
                break
            candidatos.sort(reverse=True)
            _, i, v = candidatos[0]
            for _ in range(12):
                if self.unidades[i] < 2 or self.dueño[v] == fid:
                    break
                if self.unidades[i] <= self.unidades[v] and self.rng.random() > agr:
                    break
                r = self.atacar(i, v, fid)
                if r.conquista:
                    if self.unidades[v] > 3 and self.unidades[i] == 1 and self.rng.random() < 0.5:
                        k = self.unidades[v] // 2
                        self.unidades[v] -= k
                        self.unidades[i] += k
                    break
            ataques += 1
            if self.terminado:
                return
        # movimiento: del interior a la frontera
        provs = self.provincias_de(fid)
        interior = [i for i in provs if all(self.dueño[v] == fid for v in self.mapa.provincias[i]["vecinos"]) and self.unidades[i] > 2]
        if interior:
            o = max(interior, key=lambda i: self.unidades[i])
            dest = [d for d in self.alcanzables_para_mover(fid, o) if any(self.dueño[v] != fid for v in self.mapa.provincias[d]["vecinos"])]
            if dest:
                d = max(dest, key=lambda i: self._amenaza(i, fid))
                k = self.unidades[o] - 1
                self.unidades[o] -= k
                self.unidades[d] += k

    # ------------------------------------------------------------ fin de turno
    def terminar_turno(self):
        if self.terminado:
            return
        for fid in self.orden:
            f = self.facciones[fid]
            if f.viva and not f.es_jugador:
                self.turno_ia(fid)
                if self.terminado:
                    return
        # límite logístico por provincia
        for i in range(self.n):
            if self.unidades[i] > 60:
                self.unidades[i] = 60
        # crecimiento neutral
        for i in range(self.n):
            if self.dueño[i] is None and self.unidades[i] < FUERZA_NEUTRAL.get(self.mapa.provincias[i]["terreno"], 2) and self.rng.random() < 0.3:
                self.unidades[i] += 1
        for f in self.facciones.values():
            if f.viva:
                f.max_provincias = max(f.max_provincias, len(self.provincias_de(f.id)))
        # avanzar año
        self.turno += 1
        self.año += AÑOS_POR_TURNO
        self.fase = "refuerzo"
        self.fortificado = False
        self.conquisto_este_turno = False
        if self.año in ERAS:
            self._cerrar_era()
        self._disparar_eventos()
        if self.jugador:
            self.refuerzos = self.calcular_refuerzos(self.jugador)
        if self.año >= AÑO_FINAL:
            self._guardar_mapa_era(AÑO_FINAL)
            self.terminado = True
            self.resultado = "final"

    def registrar(self, texto, color=(220, 220, 220)):
        self.log.append((self.año, texto, color))
        if len(self.log) > 400:
            self.log = self.log[-400:]

    # ------------------------------------------------------------ eras y eventos
    def _guardar_mapa_era(self, año):
        ranking = sorted(self.facciones_vivas(), key=lambda f: (-len(self.provincias_de(f.id)), -self.poder(f.id)))
        resumen = [(f.id, f.nombre, len(self.provincias_de(f.id)), self.poder(f.id)) for f in ranking]
        self.mapas_era[año] = dict(dueño=list(self.dueño), unidades=list(self.unidades), resumen=resumen,
                                   nombres={f.id: f.nombre for f in self.facciones.values()},
                                   colores={f.id: f.color for f in self.facciones.values()})

    def _cerrar_era(self):
        self._guardar_mapa_era(self.año)
        anterior = self.mapas_era.get(self.año - 100)
        lineas = []
        actual = self.mapas_era[self.año]
        if anterior:
            prev = {r[0]: r[2] for r in anterior["resumen"]}
            for fid, nombre, nprov, pod in actual["resumen"][:8]:
                delta = nprov - prev.get(fid, 0)
                signo = "+" if delta >= 0 else ""
                lineas.append(f"{nombre}: {nprov} provincias ({signo}{delta})")
            desaparecidas = [self.facciones[fid].nombre for fid in prev if not self.facciones[fid].viva]
            if desaparecidas:
                lineas.append("Desaparecieron: " + ", ".join(desaparecidas))
            nuevas = [self.facciones[r[0]].nombre for r in actual["resumen"] if r[0] not in prev]
            if nuevas:
                lineas.append("Surgieron: " + ", ".join(nuevas))
        self.balance_era = lineas
        self.cola_eventos.append(dict(tipo="era", año=self.año, titulo=f"Nuevo mapa: año {self.año}",
                                      texto="Se ha guardado el mapa de esta era en el Atlas.", lineas=lineas))

    def _disparar_eventos(self):
        for k, ev in enumerate(EVENTOS):
            if k in self.eventos_disparados:
                continue
            if ev["año"] <= self.año:
                self.eventos_disparados.add(k)
                notas = []
                for ef in ev["efectos"]:
                    nota = self.aplicar_efecto(ef)
                    if nota:
                        notas.append(nota)
                self.registrar(ev["titulo"], (255, 230, 150))
                self.cola_eventos.append(dict(tipo="evento", año=ev["año"], titulo=ev["titulo"], texto=ev["texto"],
                                              faccion=ev.get("faccion"), lineas=notas))

    def aplicar_efecto(self, ef):
        tipo = ef[0]
        F = self.facciones
        if tipo == "refuerzo":
            f = F[ef[1]]
            if not f.viva:
                return None
            cap = self.mapa.idx(f.capital)
            dest = cap if self.dueño[cap] == f.id else (self.provincias_de(f.id) or [None])[0]
            if dest is None:
                return None
            self.unidades[dest] += ef[2]
            return f"{f.nombre} recibe {ef[2]} unidades."
        if tipo == "boost":
            f = F[ef[1]]
            provs = self.provincias_de(f.id)
            if not f.viva or not provs:
                return None
            for k in range(ef[2]):
                self.unidades[provs[k % len(provs)]] += 1
            return f"{f.nombre} se fortalece (+{ef[2]})."
        if tipo == "debilitar":
            f = F[ef[1]]
            provs = self.provincias_de(f.id)
            if not f.viva or not provs:
                return None
            quitadas = 0
            for k in range(ef[2] * 3):
                i = provs[k % len(provs)]
                if self.unidades[i] > 1 and quitadas < ef[2]:
                    self.unidades[i] -= 1
                    quitadas += 1
            return f"{f.nombre} se debilita (-{quitadas})."
        if tipo == "colapso":
            f = F[ef[1]]
            if not f.viva:
                return None
            if f.es_jugador:
                for i in self.provincias_de(f.id):
                    self.unidades[i] = max(1, self.unidades[i] // 2)
                return f"La historia golpea a {f.nombre}: pierdes la mitad de tus ejércitos, pero resistes."
            for i in self.provincias_de(f.id):
                self.dueño[i] = NEUTRAL
                self.unidades[i] = max(1, min(3, self.unidades[i] // 2))
            f.viva = False
            f.eliminada_en = self.año
            f.eliminada_por = "historia"
            return f"{f.nombre} se desintegra; sus tierras quedan en manos de pueblos locales."
        if tipo == "perder":
            f = F[ef[1]]
            i = self.mapa.idx(ef[2])
            if self.dueño[i] != f.id or f.es_jugador:
                return None
            if len(self.provincias_de(f.id)) <= 1:
                return None
            self.dueño[i] = NEUTRAL
            self.unidades[i] = max(1, self.unidades[i] // 2)
            return f"{f.nombre} abandona {self.mapa.provincias[i]['nombre']}."
        if tipo == "ganar":
            f = F[ef[1]]
            i = self.mapa.idx(ef[2])
            if not f.viva:
                revivir = len(ef) > 4 and ef[4]
                if not revivir or f.eliminada_por == "historia" or (self.dueño[i] is not None and F[self.dueño[i]].es_jugador):
                    return None
                f.viva, f.aparecio, f.eliminada_en, f.eliminada_por = True, True, None, None
            d = self.dueño[i]
            if d == f.id:
                self.unidades[i] += ef[3]
                return None
            if d is not None and F[d].es_jugador:
                # el jugador retiene la provincia; la facción histórica presiona con refuerzos
                provs = self.provincias_de(f.id)
                if provs:
                    self.unidades[provs[0]] += ef[3]
                return f"{f.nombre} reclama {self.mapa.provincias[i]['nombre']}, pero tú la controlas: resistes la historia."
            self.dueño[i] = f.id
            self.unidades[i] = ef[3]
            if d is not None and not self.provincias_de(d):
                F[d].viva = False
                F[d].eliminada_en = self.año
                F[d].eliminada_por = f.id
            return f"{f.nombre} se establece en {self.mapa.provincias[i]['nombre']}."
        if tipo == "nueva":
            f = F[ef[1]]
            if f.viva:
                return None
            self._asentar(f)
            return f"Surge una nueva potencia: {f.nombre}."
        if tipo == "renombrar":
            f = F[ef[1]]
            if not f.viva:
                return None
            viejo = f.nombre
            f.nombre = ef[2]
            if ef[3]:
                f.capital = ef[3]
            return f"{viejo} pasa a llamarse {f.nombre}."
        if tipo == "rasgo":
            f = F[ef[1]]
            if not f.viva:
                return None
            f.rasgos[ef[2]] = ef[3]
            return None
        if tipo == "anexion":
            g, p = F[ef[1]], F[ef[2]]
            if not g.viva or not p.viva:
                return None
            if p.es_jugador:
                provs = self.provincias_de(g.id)
                for k in range(6):
                    if provs:
                        self.unidades[provs[k % len(provs)]] += 1
                return f"{g.nombre} lanza sus ejércitos contra ti. La historia dice que caerás... demuéstrale lo contrario."
            if g.es_jugador:
                return f"La historia dice que {g.nombre} conquistó a {p.nombre}. ¡Depende de ti lograrlo!"
            for i in self.provincias_de(p.id):
                self.dueño[i] = g.id
                self.unidades[i] = max(1, self.unidades[i])
            p.viva = False
            p.eliminada_en = self.año
            p.eliminada_por = g.id
            return f"{g.nombre} conquista a {p.nombre}."
        if tipo == "sequia":
            for pid in ef[1]:
                i = self.mapa.idx(pid)
                self.unidades[i] = max(1, self.unidades[i] - ef[2])
            return "Sequía: los ejércitos de la región se reducen."
        return None

    # ------------------------------------------------------------ puntuación
    def ranking(self):
        vivos = self.facciones_vivas()
        return sorted(vivos, key=lambda f: (-len(self.provincias_de(f.id)), -self.poder(f.id)))

    # ------------------------------------------------------------ guardar / cargar
    def a_dict(self):
        return dict(semilla=self.semilla, rng=self.rng.getstate(), dueño=self.dueño, unidades=self.unidades, año=self.año,
                    turno=self.turno, jugador=self.jugador, fase=self.fase, refuerzos=self.refuerzos,
                    fortificado=self.fortificado, log=self.log[-100:], mapas_era={str(k): v for k, v in self.mapas_era.items()},
                    terminado=self.terminado, resultado=self.resultado, eventos=sorted(self.eventos_disparados),
                    facciones={k: f.a_dict() for k, f in self.facciones.items()})

    def guardar(self, ruta):
        d = self.a_dict()
        d["rng"] = None
        with open(ruta, "w", encoding="utf-8") as fh:
            json.dump(d, fh, ensure_ascii=False)

    @classmethod
    def cargar(cls, ruta):
        with open(ruta, "r", encoding="utf-8") as fh:
            d = json.load(fh)
        j = cls(jugador_id=d["jugador"], semilla=d["semilla"])
        j.dueño = d["dueño"]
        j.unidades = d["unidades"]
        j.año, j.turno, j.fase = d["año"], d["turno"], d["fase"]
        j.refuerzos, j.fortificado = d["refuerzos"], d["fortificado"]
        j.log = [tuple(x) for x in d["log"]]
        j.mapas_era = {int(k): v for k, v in d["mapas_era"].items()}
        for k, v in j.mapas_era.items():
            v["colores"] = {a: tuple(b) for a, b in v["colores"].items()}
        j.terminado, j.resultado = d["terminado"], d["resultado"]
        j.eventos_disparados = set(d["eventos"])
        for k, fd in d["facciones"].items():
            j.facciones[k].de_dict(fd)
        j.cola_eventos = []
        return j
