# -*- coding: utf-8 -*-
"""Renderizado del mapa en estilo 8 bits."""
import pygame

MAR = (24, 44, 84)
MAR_CLARO = (36, 62, 110)
BORDE = (18, 14, 10)
COSTA = (10, 22, 46)
TERRENO_NEUTRAL = dict(tundra=(210, 214, 220), taiga=(92, 120, 84), bosque=(84, 132, 72), llanura=(170, 168, 96),
                       desierto=(214, 184, 120), costa=(150, 160, 110), selva=(52, 116, 60), montaña=(140, 124, 110),
                       altiplano=(160, 140, 100), isla=(150, 170, 120))


def oscurecer(c, f=0.7):
    return tuple(max(0, min(255, int(x * f))) for x in c)


def aclarar(c, f=1.25):
    return tuple(max(0, min(255, int(x * f))) for x in c)


def color_provincia(juego, i):
    d = juego.dueño[i]
    if d is None:
        return TERRENO_NEUTRAL.get(juego.mapa.provincias[i]["terreno"], (150, 150, 120))
    return juego.facciones[d].color


class RenderMapa:
    """Mantiene una superficie del mapa por nivel de zoom, regenerada cuando cambian los dueños."""
    ZOOMS = [3, 4, 6, 8, 12]

    def __init__(self, mapa):
        self.mapa = mapa
        self.cache = {}
        self.version = -1
        # celdas costeras: tierra con al menos un vecino de mar (para dibujar contorno)
        self.costa = set()
        for r in range(mapa.rows):
            for c in range(mapa.cols):
                if mapa.tierra[r][c]:
                    for dc, dr in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        cc, rr = c + dc, r + dr
                        if not (0 <= cc < mapa.cols and 0 <= rr < mapa.rows) or not mapa.tierra[rr][cc]:
                            self.costa.add((c, r))
                            break
        # patrón de olas fijo
        import random
        rng = random.Random(3)
        self.olas = [(rng.randrange(mapa.cols), rng.randrange(mapa.rows)) for _ in range(700)]
        self.olas = [(c, r) for c, r in self.olas if not mapa.tierra[r][c]]

    def invalidar(self):
        self.cache.clear()

    def superficie(self, juego, s, version):
        if version != self.version:
            self.cache.clear()
            self.version = version
        if s in self.cache:
            return self.cache[s]
        m = self.mapa
        surf = pygame.Surface((m.cols * s, m.rows * s))
        surf.fill(MAR)
        for c, r in self.olas:
            pygame.draw.rect(surf, MAR_CLARO, (c * s, r * s + s // 2, s, max(1, s // 3)))
        colores = [color_provincia(juego, i) for i in range(len(m.provincias))]
        pc = m.prov_de_celda
        for r in range(m.rows):
            fila = pc[r]
            for c in range(m.cols):
                i = fila[c]
                if i < 0:
                    continue
                col = colores[i]
                # textura suave de dos tonos (tablero) para el look de 8 bits
                if (c + r) & 1:
                    col = oscurecer(col, 0.92)
                pygame.draw.rect(surf, col, (c * s, r * s, s, s))
        # bordes entre provincias y costa
        for r in range(m.rows):
            fila = pc[r]
            for c in range(m.cols):
                i = fila[c]
                if i < 0:
                    continue
                x, y = c * s, r * s
                if (c, r) in self.costa:
                    for dc, dr in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        cc, rr = c + dc, r + dr
                        if not (0 <= cc < m.cols and 0 <= rr < m.rows) or not m.tierra[rr][cc]:
                            if dc == 1:
                                pygame.draw.line(surf, COSTA, (x + s - 1, y), (x + s - 1, y + s - 1))
                            elif dc == -1:
                                pygame.draw.line(surf, COSTA, (x, y), (x, y + s - 1))
                            elif dr == 1:
                                pygame.draw.line(surf, COSTA, (x, y + s - 1), (x + s - 1, y + s - 1))
                            else:
                                pygame.draw.line(surf, COSTA, (x, y), (x + s - 1, y))
                if c + 1 < m.cols and fila[c + 1] >= 0 and fila[c + 1] != i:
                    pygame.draw.line(surf, BORDE, (x + s - 1, y), (x + s - 1, y + s - 1))
                if r + 1 < m.rows and pc[r + 1][c] >= 0 and pc[r + 1][c] != i:
                    pygame.draw.line(surf, BORDE, (x, y + s - 1), (x + s - 1, y + s - 1))
        # rutas marítimas (líneas punteadas)
        for a, b in m.rutas_mar:
            ca, cb = m.provincias[a]["centro"], m.provincias[b]["centro"]
            x1, y1 = ca[0] * s + s // 2, ca[1] * s + s // 2
            x2, y2 = cb[0] * s + s // 2, cb[1] * s + s // 2
            n = max(2, int(((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5 / (s * 1.2)))
            for k in range(n + 1):
                if k % 2 == 0:
                    t = k / n
                    pygame.draw.rect(surf, (120, 160, 200), (int(x1 + (x2 - x1) * t) - 1, int(y1 + (y2 - y1) * t) - 1, 2, 2))
        self.cache[s] = surf
        return surf


def dibujar_dado(surf, x, y, tam, valor, color_fondo=(240, 236, 220), color_punto=(20, 20, 20)):
    """Dado pixelado."""
    pygame.draw.rect(surf, (30, 30, 30), (x, y, tam, tam))
    pygame.draw.rect(surf, color_fondo, (x + 2, y + 2, tam - 4, tam - 4))
    p = max(2, tam // 7)
    cx, cy = x + tam // 2, y + tam // 2
    off = tam // 4
    puntos = {1: [(0, 0)], 2: [(-1, -1), (1, 1)], 3: [(-1, -1), (0, 0), (1, 1)], 4: [(-1, -1), (1, -1), (-1, 1), (1, 1)],
              5: [(-1, -1), (1, -1), (0, 0), (-1, 1), (1, 1)], 6: [(-1, -1), (1, -1), (-1, 0), (1, 0), (-1, 1), (1, 1)]}
    for dx, dy in puntos.get(max(1, min(6, valor)), []):
        pygame.draw.rect(surf, color_punto, (cx + dx * off - p // 2, cy + dy * off - p // 2, p, p))


def dibujar_guerrero(surf, x, y, color, escala=2):
    """Pequeño sprite de guerrero (8x8) en el color de la facción."""
    sprite = [
        "..XXXX..",
        ".XXXXXX.",
        ".X.XX.X.",
        "..XXXX..",
        "XXXXXXXX",
        "X.XXXX.X",
        "..X..X..",
        ".XX..XX.",
    ]
    for r, fila in enumerate(sprite):
        for c, ch in enumerate(fila):
            if ch == "X":
                pygame.draw.rect(surf, color, (x + c * escala, y + r * escala, escala, escala))
