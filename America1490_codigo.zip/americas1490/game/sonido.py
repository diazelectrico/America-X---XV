# -*- coding: utf-8 -*-
"""Sonidos 8 bits sintetizados en tiempo de ejecución (sin archivos externos ni numpy)."""
import array, math
import pygame


def _onda(frecuencias, duracion=0.12, volumen=0.25, forma="cuadrada", tasa=22050):
    """Genera un pygame.Sound a partir de una secuencia de frecuencias (arpegio)."""
    n_total = int(tasa * duracion * len(frecuencias))
    datos = array.array("h")
    por_nota = n_total // max(1, len(frecuencias))
    for f in frecuencias:
        for k in range(por_nota):
            t = k / tasa
            env = 1.0 - k / por_nota           # decaimiento lineal
            if forma == "cuadrada":
                v = 1.0 if math.sin(2 * math.pi * f * t) >= 0 else -1.0
            elif forma == "triangulo":
                v = 2.0 * abs(2.0 * ((t * f) % 1.0) - 1.0) - 1.0
            else:  # ruido
                v = ((k * 7919 + 13) % 251) / 125.0 - 1.0
            datos.append(int(32767 * volumen * env * v))
    try:
        return pygame.mixer.Sound(buffer=datos.tobytes())
    except Exception:
        return None


class Sonidos:
    def __init__(self):
        self.ok = False
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(frequency=22050, size=-16, channels=1)
            pygame.mixer.set_num_channels(8)
            self.ok = pygame.mixer.get_init() is not None
        except Exception:
            self.ok = False
        if not self.ok:
            return
        self.s_click = _onda([880], 0.05, 0.15)
        self.s_colocar = _onda([660, 990], 0.05, 0.18)
        self.s_dados = _onda([200, 300, 250, 400, 350, 500], 0.04, 0.2, "ruido")
        self.s_conquista = _onda([523, 659, 784, 1047], 0.09, 0.22)
        self.s_eliminacion = _onda([440, 415, 392, 330, 262], 0.12, 0.22, "triangulo")
        self.s_evento = _onda([784, 988, 1175], 0.08, 0.18, "triangulo")
        self.s_era = _onda([392, 523, 659, 784, 1047, 1319], 0.1, 0.22)

    def _p(self, s):
        if self.ok and s is not None:
            try:
                s.play()
            except Exception:
                pass

    def click(self):
        self._p(getattr(self, "s_click", None))

    def colocar(self):
        self._p(getattr(self, "s_colocar", None))

    def dados(self):
        self._p(getattr(self, "s_dados", None))

    def conquista(self):
        self._p(getattr(self, "s_conquista", None))

    def eliminacion(self):
        self._p(getattr(self, "s_eliminacion", None))

    def evento(self):
        self._p(getattr(self, "s_evento", None))

    def era(self):
        self._p(getattr(self, "s_era", None))
