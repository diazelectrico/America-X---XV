# -*- coding: utf-8 -*-
"""Interfaz gráfica en estilo 8 bits (pygame)."""
import os, sys, math, random, datetime
import pygame
from .motor import Juego
from .facciones import FACCIONES
from .render import RenderMapa, dibujar_dado, dibujar_guerrero, oscurecer, aclarar, color_provincia
from . import sonido

ANCHO, ALTO = 1280, 800
PANEL_W = 380
BARRA_H = 40
MAPA_RECT = pygame.Rect(0, BARRA_H, ANCHO - PANEL_W, ALTO - BARRA_H)
PANEL_RECT = pygame.Rect(ANCHO - PANEL_W, BARRA_H, PANEL_W, ALTO - BARRA_H)

# paleta 8 bits
C_FONDO = (26, 22, 30)
C_PANEL = (40, 34, 46)
C_PANEL2 = (54, 46, 62)
C_TEXTO = (236, 228, 208)
C_TEXTO2 = (170, 162, 150)
C_ACENTO = (250, 200, 60)
C_OK = (110, 210, 120)
C_MAL = (230, 90, 80)
C_AZUL = (110, 170, 240)
C_BORDE = (120, 104, 80)


def ruta_recurso(rel):
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return os.path.join(base, rel)


def ruta_datos_usuario():
    """Carpeta donde se guardan partidas y mapas (junto al ejecutable o al proyecto)."""
    if getattr(sys, "frozen", False):
        base = os.path.dirname(sys.executable)
    else:
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    d = os.path.join(base, "partidas")
    os.makedirs(d, exist_ok=True)
    return d


class Fuentes:
    def __init__(self):
        ruta = ruta_recurso(os.path.join("assets", "PressStart2P.ttf"))
        self._ok = os.path.exists(ruta)
        self.cache = {}
        self.ruta = ruta

    def get(self, tam):
        if tam not in self.cache:
            if self._ok:
                self.cache[tam] = pygame.font.Font(self.ruta, tam)
            else:
                self.cache[tam] = pygame.font.SysFont("monospace", tam + 4, bold=True)
        return self.cache[tam]


class Boton:
    def __init__(self, rect, texto, accion, color=C_PANEL2, tecla=None):
        self.rect = pygame.Rect(rect)
        self.texto = texto
        self.accion = accion
        self.color = color
        self.tecla = tecla
        self.activo = True

    def dibujar(self, surf, fuente, raton):
        col = self.color
        if not self.activo:
            col = oscurecer(col, 0.6)
        elif self.rect.collidepoint(raton):
            col = aclarar(col, 1.3)
        pygame.draw.rect(surf, (12, 10, 14), self.rect.move(3, 3))
        pygame.draw.rect(surf, col, self.rect)
        pygame.draw.rect(surf, C_BORDE, self.rect, 2)
        t = fuente.render(self.texto, False, C_TEXTO if self.activo else C_TEXTO2)
        surf.blit(t, (self.rect.centerx - t.get_width() // 2, self.rect.centery - t.get_height() // 2))

    def click(self, pos):
        if self.activo and self.rect.collidepoint(pos):
            self.accion()
            return True
        return False


def envolver(fuente, texto, ancho):
    """Divide texto en líneas que caben en `ancho` píxeles."""
    lineas = []
    for parrafo in texto.split("\n"):
        palabras = parrafo.split(" ")
        actual = ""
        for p in palabras:
            prueba = (actual + " " + p).strip()
            if fuente.size(prueba)[0] <= ancho:
                actual = prueba
            else:
                if actual:
                    lineas.append(actual)
                # palabra demasiado larga: cortar
                while fuente.size(p)[0] > ancho and len(p) > 1:
                    k = len(p)
                    while k > 1 and fuente.size(p[:k])[0] > ancho:
                        k -= 1
                    lineas.append(p[:k])
                    p = p[k:]
                actual = p
        lineas.append(actual)
    return lineas


def dibujar_texto(surf, fuente, texto, x, y, color=C_TEXTO, ancho=None, interlinea=4):
    if ancho is None:
        surf.blit(fuente.render(texto, False, color), (x, y))
        return y + fuente.get_height() + interlinea
    for linea in envolver(fuente, texto, ancho):
        surf.blit(fuente.render(linea, False, color), (x, y))
        y += fuente.get_height() + interlinea
    return y


def marco(surf, rect, color=C_PANEL, borde=C_BORDE):
    pygame.draw.rect(surf, color, rect)
    pygame.draw.rect(surf, borde, rect, 3)
    pygame.draw.rect(surf, (12, 10, 14), rect, 1)


# =====================================================================================
class App:
    def __init__(self):
        pygame.init()
        try:
            pygame.mixer.init()
        except Exception:
            pass
        pygame.display.set_caption("América 1000-1490: Imperios antes de Colón")
        self.pantalla = pygame.display.set_mode((ANCHO, ALTO))
        self.reloj = pygame.time.Clock()
        self.fuentes = Fuentes()
        self.f8 = self.fuentes.get(8)
        self.f10 = self.fuentes.get(10)
        self.f12 = self.fuentes.get(12)
        self.f16 = self.fuentes.get(16)
        self.f24 = self.fuentes.get(24)
        self.sonido = sonido.Sonidos()
        self.estado = "menu"        # menu, seleccion, juego, atlas, ayuda, final
        self.juego = None
        self.render = None
        self.zoom_i = 1
        self.desplazamiento = [0, 0]
        self.arrastrando = None
        self.seleccion = None
        self.hover = None
        self.modal = None            # dict describiendo un cuadro modal
        self.version_mapa = 0
        self.mensaje = ""
        self.mensaje_t = 0
        self.scroll_panel = 0
        self.scroll_lista = 0
        self.faccion_elegida = 0
        self.botones = []
        self.pestaña = "provincia"   # provincia / faccion / registro
        self.animacion_dados = None
        self.ticks = 0
        self.corriendo = True
        self.mapas_exportados = set()
        from .mapa import Mapa
        self.mapa_base = Mapa(7)
        self.minimapa_cache = {}

    def minimapa(self, provincias_resaltadas, color, esc=1.3):
        """Mapa pequeño con las provincias iniciales de un pueblo resaltadas."""
        clave = (tuple(provincias_resaltadas), color)
        if clave in self.minimapa_cache:
            return self.minimapa_cache[clave]
        m = self.mapa_base
        surf = pygame.Surface((m.cols, m.rows))
        surf.fill((24, 44, 84))
        marcadas = {m.idx(p) for p in provincias_resaltadas if p in m.indice}
        for r in range(m.rows):
            for c in range(m.cols):
                i = m.prov_de_celda[r][c]
                if i >= 0:
                    surf.set_at((c, r), color if i in marcadas else (120, 118, 96))
        surf = pygame.transform.scale(surf, (int(m.cols * esc), int(m.rows * esc)))
        self.minimapa_cache[clave] = surf
        return surf

    # --------------------------------------------------------------------- utilidades
    def avisar(self, texto, ms=2500):
        self.mensaje = texto
        self.mensaje_t = pygame.time.get_ticks() + ms

    def nueva_partida(self, fid):
        self.juego = Juego(jugador_id=fid)
        self.render = RenderMapa(self.juego.mapa)
        self.version_mapa += 1
        self.seleccion = None
        self.estado = "juego"
        self.zoom_i = 1
        self.centrar_en_faccion()
        self.procesar_cola()
        self.exportar_mapa_era(1000)

    def cargar_partida(self):
        ruta = os.path.join(ruta_datos_usuario(), "partida.json")
        if not os.path.exists(ruta):
            self.avisar("No hay partida guardada")
            return
        try:
            self.juego = Juego.cargar(ruta)
        except Exception as e:
            self.avisar("Error al cargar: " + str(e)[:40])
            return
        self.render = RenderMapa(self.juego.mapa)
        self.version_mapa += 1
        self.estado = "juego"
        self.centrar_en_faccion()
        self.avisar("Partida cargada")

    def guardar_partida(self):
        ruta = os.path.join(ruta_datos_usuario(), "partida.json")
        self.juego.guardar(ruta)
        self.avisar("Partida guardada en la carpeta 'partidas'")

    def centrar_en_faccion(self):
        j = self.juego
        provs = j.provincias_de(j.jugador)
        if not provs:
            return
        cap = j.mapa.idx(j.facciones[j.jugador].capital)
        i = cap if cap in provs else provs[0]
        c, r = j.mapa.provincias[i]["centro"]
        s = self.zoom()
        self.desplazamiento = [MAPA_RECT.width // 2 - c * s, MAPA_RECT.height // 2 - r * s]
        self.limitar_desplazamiento()

    def zoom(self):
        return RenderMapa.ZOOMS[self.zoom_i]

    def limitar_desplazamiento(self):
        s = self.zoom()
        w, h = self.juego.mapa.cols * s, self.juego.mapa.rows * s
        self.desplazamiento[0] = max(MAPA_RECT.width - w - 40, min(40, self.desplazamiento[0]))
        self.desplazamiento[1] = max(MAPA_RECT.height - h - 40, min(40, self.desplazamiento[1]))

    def cambiar_zoom(self, delta, pos=None):
        viejo = self.zoom()
        nuevo_i = max(0, min(len(RenderMapa.ZOOMS) - 1, self.zoom_i + delta))
        if nuevo_i == self.zoom_i:
            return
        self.zoom_i = nuevo_i
        nuevo = self.zoom()
        if pos is None:
            pos = MAPA_RECT.center
        mx, my = pos[0] - MAPA_RECT.x, pos[1] - MAPA_RECT.y
        # mantener el punto bajo el ratón
        cx = (mx - self.desplazamiento[0]) / viejo
        cy = (my - self.desplazamiento[1]) / viejo
        self.desplazamiento = [int(mx - cx * nuevo), int(my - cy * nuevo)]
        self.limitar_desplazamiento()

    def provincia_en(self, pos):
        if not MAPA_RECT.collidepoint(pos) or self.juego is None:
            return None
        s = self.zoom()
        c = (pos[0] - MAPA_RECT.x - self.desplazamiento[0]) // s
        r = (pos[1] - MAPA_RECT.y - self.desplazamiento[1]) // s
        m = self.juego.mapa
        if 0 <= c < m.cols and 0 <= r < m.rows:
            i = m.prov_de_celda[r][c]
            return i if i >= 0 else None
        return None

    def procesar_cola(self):
        """Muestra el siguiente evento histórico pendiente como cuadro modal."""
        if self.modal is not None or self.juego is None:
            return
        if self.juego.cola_eventos:
            ev = self.juego.cola_eventos.pop(0)
            self.modal = dict(tipo=ev["tipo"], datos=ev)
            if ev["tipo"] == "era":
                self.exportar_mapa_era(ev["año"])
                self.sonido.era()
            else:
                self.sonido.evento()
        elif self.juego.terminado and self.estado == "juego":
            self.exportar_mapa_era(1490)
            self.estado = "final"

    def exportar_mapa_era(self, año):
        """Guarda una imagen PNG del mapa de la era en la carpeta 'partidas/mapas'."""
        if año in self.mapas_exportados or self.juego is None:
            return
        self.mapas_exportados.add(año)
        try:
            d = os.path.join(ruta_datos_usuario(), "mapas")
            os.makedirs(d, exist_ok=True)
            surf = self.render.superficie(self.juego, 4, self.version_mapa).copy()
            self.dibujar_etiquetas(surf, 4, (0, 0), completo=True)
            t = self.f16.render(f"AMERICA {año}", False, C_TEXTO)
            surf.blit(t, (10, 10))
            pygame.image.save(surf, os.path.join(d, f"mapa_{año}.png"))
        except Exception:
            pass

    # --------------------------------------------------------------------- bucle
    def ejecutar(self):
        while self.corriendo:
            self.ticks = pygame.time.get_ticks()
            raton = pygame.mouse.get_pos()
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    self.corriendo = False
                elif ev.type == pygame.KEYDOWN and ev.key == pygame.K_F11:
                    pygame.display.toggle_fullscreen()
                else:
                    self.evento(ev, raton)
            self.dibujar(raton)
            pygame.display.flip()
            self.reloj.tick(60)
        pygame.quit()

    # --------------------------------------------------------------------- eventos
    def evento(self, ev, raton):
        if self.estado == "menu":
            self.evento_menu(ev)
        elif self.estado == "seleccion":
            self.evento_seleccion(ev)
        elif self.estado == "juego":
            self.evento_juego(ev, raton)
        elif self.estado == "atlas":
            if ev.type == pygame.KEYDOWN and ev.key in (pygame.K_ESCAPE, pygame.K_a) or ev.type == pygame.MOUSEBUTTONDOWN:
                self.estado = "juego" if self.juego and not self.juego.terminado else ("final" if self.juego else "menu")
        elif self.estado == "ayuda":
            if ev.type == pygame.KEYDOWN or ev.type == pygame.MOUSEBUTTONDOWN:
                self.estado = self.estado_previo
        elif self.estado == "final":
            if ev.type == pygame.MOUSEBUTTONDOWN:
                for b in self.botones:
                    b.click(ev.pos)
            if ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE:
                self.estado = "menu"

    def evento_menu(self, ev):
        if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
            for b in self.botones:
                b.click(ev.pos)
        if ev.type == pygame.KEYDOWN and ev.key == pygame.K_RETURN:
            self.estado = "seleccion"

    def evento_seleccion(self, ev):
        lista = self.facciones_seleccionables()
        if ev.type == pygame.KEYDOWN:
            if ev.key == pygame.K_ESCAPE:
                self.estado = "menu"
            elif ev.key in (pygame.K_DOWN, pygame.K_s):
                self.faccion_elegida = (self.faccion_elegida + 1) % len(lista)
            elif ev.key in (pygame.K_UP, pygame.K_w):
                self.faccion_elegida = (self.faccion_elegida - 1) % len(lista)
            elif ev.key == pygame.K_RETURN:
                self.nueva_partida(lista[self.faccion_elegida]["id"])
        elif ev.type == pygame.MOUSEWHEEL:
            self.faccion_elegida = max(0, min(len(lista) - 1, self.faccion_elegida - ev.y))
        elif ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
            for b in self.botones:
                if b.click(ev.pos):
                    return
            # clic en la lista
            x0, y0 = 40, 110
            for k in range(len(lista)):
                fila = pygame.Rect(x0, y0 + k * 22 - self.scroll_lista, 420, 22)
                if fila.collidepoint(ev.pos) and 100 < ev.pos[1] < ALTO - 80:
                    if self.faccion_elegida == k:
                        self.nueva_partida(lista[k]["id"])
                    self.faccion_elegida = k
                    self.sonido.click()
                    return

    def facciones_seleccionables(self):
        return [f for f in FACCIONES if f["inicio"] <= 1000]

    def evento_juego(self, ev, raton):
        j = self.juego
        # modal tiene prioridad
        if self.modal:
            if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
                for b in self.botones_modal:
                    if b.click(ev.pos):
                        return
            if ev.type == pygame.KEYDOWN and ev.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_ESCAPE):
                if self.modal["tipo"] == "dados":
                    if ev.key == pygame.K_ESCAPE:
                        self.cerrar_modal()
                    elif self.modal["datos"].get("puede_seguir"):
                        self.atacar_de_nuevo()
                    else:
                        self.cerrar_modal()
                else:
                    self.cerrar_modal()
            return
        if ev.type == pygame.KEYDOWN:
            if ev.key == pygame.K_ESCAPE:
                self.seleccion = None
            elif ev.key == pygame.K_SPACE or ev.key == pygame.K_RETURN:
                self.siguiente_fase()
            elif ev.key == pygame.K_a:
                self.estado = "atlas"
            elif ev.key == pygame.K_h or ev.key == pygame.K_F1:
                self.estado_previo = "juego"
                self.estado = "ayuda"
            elif ev.key == pygame.K_g:
                self.guardar_partida()
            elif ev.key in (pygame.K_PLUS, pygame.K_KP_PLUS, pygame.K_e):
                self.cambiar_zoom(1)
            elif ev.key in (pygame.K_MINUS, pygame.K_KP_MINUS, pygame.K_q):
                self.cambiar_zoom(-1)
            elif ev.key == pygame.K_c:
                self.centrar_en_faccion()
            elif ev.key == pygame.K_TAB:
                orden = ["provincia", "faccion", "registro"]
                self.pestaña = orden[(orden.index(self.pestaña) + 1) % 3]
            elif ev.key == pygame.K_m:
                self.estado_previo = "juego"
                self.estado = "menu"
        elif ev.type == pygame.MOUSEWHEEL:
            if PANEL_RECT.collidepoint(raton):
                self.scroll_panel = max(0, self.scroll_panel - ev.y * 30)
            else:
                self.cambiar_zoom(1 if ev.y > 0 else -1, raton)
        elif ev.type == pygame.MOUSEBUTTONDOWN:
            if ev.button == 1:
                for b in self.botones:
                    if b.click(ev.pos):
                        return
                if PANEL_RECT.collidepoint(ev.pos):
                    self.click_panel(ev.pos)
                    return
                i = self.provincia_en(ev.pos)
                if i is not None:
                    self.click_provincia(i, boton=1)
            elif ev.button == 3:
                i = self.provincia_en(ev.pos)
                if i is not None and j.fase == "refuerzo" and j.dueño[i] == j.jugador:
                    self.click_provincia(i, boton=3)
                elif i is not None and j.fase == "movimiento" and self.seleccion is not None:
                    self.click_provincia(i, boton=3)
                else:
                    self.arrastrando = (ev.pos, list(self.desplazamiento))
            elif ev.button == 2:
                self.arrastrando = (ev.pos, list(self.desplazamiento))
        elif ev.type == pygame.MOUSEBUTTONUP:
            if ev.button in (2, 3):
                self.arrastrando = None
        elif ev.type == pygame.MOUSEMOTION:
            if self.arrastrando:
                (ox, oy), (dx, dy) = self.arrastrando
                self.desplazamiento = [dx + ev.pos[0] - ox, dy + ev.pos[1] - oy]
                self.limitar_desplazamiento()
            self.hover = self.provincia_en(ev.pos)

    def click_panel(self, pos):
        # pestañas
        y = PANEL_RECT.y + 8
        for k, (nombre, etiqueta) in enumerate([("provincia", "PROVINCIA"), ("faccion", "PUEBLO"), ("registro", "CRONICA")]):
            r = pygame.Rect(PANEL_RECT.x + 8 + k * 122, y, 118, 26)
            if r.collidepoint(pos):
                self.pestaña = nombre
                self.scroll_panel = 0
                self.sonido.click()

    def click_provincia(self, i, boton=1):
        j = self.juego
        if j.terminado:
            return
        f = j.jugador
        if j.fase == "refuerzo":
            if j.dueño[i] == f and j.refuerzos > 0:
                n = 1 if boton == 1 else min(5, j.refuerzos)
                j.colocar_refuerzo(i, n)
                self.sonido.colocar()
                if j.refuerzos == 0:
                    self.avisar("Refuerzos colocados. Pulsa ESPACIO o 'Siguiente' para atacar.")
            else:
                self.seleccion = i
        elif j.fase == "ataque":
            if self.seleccion is not None and j.puede_atacar(f, self.seleccion, i):
                self.lanzar_ataque(self.seleccion, i)
            elif j.dueño[i] == f:
                self.seleccion = i if j.unidades[i] >= 2 else None
                if j.unidades[i] < 2:
                    self.avisar("Necesitas al menos 2 unidades para atacar desde aquí.")
            else:
                self.seleccion = i  # solo consultar
        elif j.fase == "movimiento":
            if self.seleccion is not None and j.dueño[self.seleccion] == f and i in j.alcanzables_para_mover(f, self.seleccion):
                total = j.unidades[self.seleccion] - 1
                n = total if boton == 1 else max(1, total // 2)
                if j.fortificar(self.seleccion, i, n):
                    self.sonido.colocar()
                    self.avisar(f"Movidas {n} unidades. Pulsa ESPACIO para terminar el turno.")
                    self.seleccion = None
                else:
                    self.avisar("Solo puedes mover una vez por turno.")
            elif j.dueño[i] == f:
                self.seleccion = i
            else:
                self.seleccion = i

    # --------------------------------------------------------------------- combate
    def lanzar_ataque(self, origen, destino):
        j = self.juego
        res = j.atacar(origen, destino, j.jugador)
        if res.detalle:
            self.avisar(res.detalle)
            return
        self.version_mapa += 1
        self.sonido.dados()
        puede_seguir = (not res.conquista) and j.unidades[origen] >= 2 and j.dueño[destino] != j.jugador
        self.modal = dict(tipo="dados", datos=dict(res=res, origen=origen, destino=destino, t0=self.ticks, puede_seguir=puede_seguir))
        if res.conquista:
            self.sonido.conquista()
            self.seleccion = None
            if res.eliminada:
                self.sonido.eliminacion()
        if j.terminado:
            pass

    def atacar_de_nuevo(self):
        d = self.modal["datos"]
        self.modal = None
        self.lanzar_ataque(d["origen"], d["destino"])

    def cerrar_modal(self):
        tipo = self.modal["tipo"] if self.modal else None
        self.modal = None
        if tipo in ("evento", "era"):
            self.procesar_cola()
        elif tipo == "dados" and self.juego.terminado:
            self.procesar_cola()

    def siguiente_fase(self):
        j = self.juego
        if j.terminado:
            return
        fase = j.fase
        j.pasar_fase()
        self.seleccion = None
        self.sonido.click()
        if fase == "movimiento":
            self.version_mapa += 1
            self.avisar(f"Año {j.año}. Turno {j.turno}: coloca {j.refuerzos} refuerzos.")
            self.procesar_cola()
        elif fase == "refuerzo":
            self.avisar("Fase de ataque: elige una provincia tuya y luego una vecina enemiga.")
        elif fase == "ataque":
            self.avisar("Movimiento: elige origen y destino (clic izq = todas, clic der = mitad).")

    # --------------------------------------------------------------------- dibujo
    def dibujar(self, raton):
        self.pantalla.fill(C_FONDO)
        if self.estado == "menu":
            self.dibujar_menu(raton)
        elif self.estado == "seleccion":
            self.dibujar_seleccion(raton)
        elif self.estado == "juego":
            self.dibujar_juego(raton)
        elif self.estado == "atlas":
            self.dibujar_atlas()
        elif self.estado == "ayuda":
            self.dibujar_ayuda()
        elif self.estado == "final":
            self.dibujar_final(raton)
        if self.mensaje and self.ticks < self.mensaje_t:
            t = self.f10.render(self.mensaje, False, C_TEXTO)
            r = pygame.Rect(0, 0, t.get_width() + 24, 30)
            r.center = (MAPA_RECT.centerx, ALTO - 30)
            pygame.draw.rect(self.pantalla, (12, 10, 14), r)
            pygame.draw.rect(self.pantalla, C_ACENTO, r, 2)
            self.pantalla.blit(t, (r.x + 12, r.y + 10))

    # ----- menú
    def dibujar_menu(self, raton):
        s = self.pantalla
        # fondo: mapa decorativo si hay juego, si no una rejilla
        for y in range(0, ALTO, 16):
            pygame.draw.line(s, (32, 28, 38), (0, y), (ANCHO, y))
        for x in range(0, ANCHO, 16):
            pygame.draw.line(s, (32, 28, 38), (x, 0), (x, ALTO))
        t = self.f24.render("AMERICA 1000-1490", False, C_ACENTO)
        s.blit(t, (ANCHO // 2 - t.get_width() // 2, 120))
        t = self.f16.render("IMPERIOS ANTES DE COLON", False, C_TEXTO)
        s.blit(t, (ANCHO // 2 - t.get_width() // 2, 165))
        t = self.f10.render("Un juego educativo de estrategia por turnos con dados", False, C_TEXTO2)
        s.blit(t, (ANCHO // 2 - t.get_width() // 2, 200))
        # sprites decorativos
        cols = [(250, 200, 0), (40, 140, 60), (230, 120, 40), (90, 190, 230), (30, 90, 170), (220, 60, 60)]
        for k, c in enumerate(cols):
            dibujar_guerrero(s, ANCHO // 2 - 150 + k * 52, 240, c, 5)
        self.botones = [
            Boton((ANCHO // 2 - 160, 330, 320, 44), "NUEVA PARTIDA", lambda: setattr(self, "estado", "seleccion")),
            Boton((ANCHO // 2 - 160, 390, 320, 44), "CARGAR PARTIDA", self.cargar_partida),
            Boton((ANCHO // 2 - 160, 450, 320, 44), "COMO SE JUEGA", self.abrir_ayuda_menu),
            Boton((ANCHO // 2 - 160, 510, 320, 44), "SALIR", lambda: setattr(self, "corriendo", False)),
        ]
        if self.juego:
            self.botones.insert(1, Boton((ANCHO // 2 - 160, 570, 320, 44), "VOLVER A LA PARTIDA", lambda: setattr(self, "estado", "juego"), color=(60, 90, 60)))
        for b in self.botones:
            b.dibujar(s, self.f12, raton)
        y = 640
        for linea in ["48 pueblos y civilizaciones - 176 provincias - 64 eventos historicos",
                      "5 mapas de era (1000, 1100, 1200, 1300, 1400) que cambian con cada conquista",
                      "Fuentes: arqueologia e historia academica; poblaciones son estimaciones"]:
            t = self.f8.render(linea, False, C_TEXTO2)
            s.blit(t, (ANCHO // 2 - t.get_width() // 2, y))
            y += 18

    def abrir_ayuda_menu(self):
        self.estado_previo = "menu"
        self.estado = "ayuda"

    # ----- selección de pueblo
    def dibujar_seleccion(self, raton):
        s = self.pantalla
        lista = self.facciones_seleccionables()
        t = self.f16.render("ELIGE TU PUEBLO (año 1000)", False, C_ACENTO)
        s.blit(t, (40, 40))
        t = self.f8.render("Flechas / rueda para moverte. ENTER o doble clic para empezar. ESC para volver.", False, C_TEXTO2)
        s.blit(t, (40, 70))
        # lista con desplazamiento
        alto_fila = 22
        visible = (ALTO - 200) // alto_fila
        if self.faccion_elegida * alto_fila - self.scroll_lista > (visible - 1) * alto_fila:
            self.scroll_lista = (self.faccion_elegida - visible + 1) * alto_fila
        if self.faccion_elegida * alto_fila < self.scroll_lista:
            self.scroll_lista = self.faccion_elegida * alto_fila
        clip = pygame.Rect(40, 100, 440, ALTO - 180)
        marco(s, clip.inflate(12, 12))
        s.set_clip(clip)
        for k, f in enumerate(lista):
            y = 110 + k * alto_fila - self.scroll_lista
            if k == self.faccion_elegida:
                pygame.draw.rect(s, C_PANEL2, (44, y - 2, 432, alto_fila))
            pygame.draw.rect(s, f["color"], (50, y + 2, 14, 14))
            pygame.draw.rect(s, (10, 10, 10), (50, y + 2, 14, 14), 1)
            t = self.f10.render(f["nombre"][:34], False, C_TEXTO if k == self.faccion_elegida else C_TEXTO2)
            s.blit(t, (72, y + 3))
        s.set_clip(None)
        # ficha del pueblo elegido
        f = lista[self.faccion_elegida]
        x0 = 520
        marco(s, pygame.Rect(x0 - 12, 88, ANCHO - x0 - 28, ALTO - 168))
        y = dibujar_texto(s, self.f12, f["nombre"], x0, 100, f["color"], ancho=ANCHO - x0 - 50)
        y += 6
        y = self.dibujar_ficha(s, f["ficha"], f["rasgos"], x0, y, ANCHO - x0 - 50, potencial=None, fid=f["id"])
        mini = self.minimapa(f["provincias"], f["color"], 1.0)
        mx, my = ANCHO - 40 - mini.get_width(), ALTO - 90 - mini.get_height()
        if my > y:
            s.blit(mini, (mx, my))
            pygame.draw.rect(s, C_BORDE, (mx, my, mini.get_width(), mini.get_height()), 1)
            # parpadeo sobre la capital
            if (self.ticks // 300) % 2 == 0 and f["capital"] in self.mapa_base.indice:
                c, r = self.mapa_base.provincias[self.mapa_base.idx(f["capital"])]["centro"]
                pygame.draw.rect(s, (255, 255, 255), (mx + c - 3, my + r - 3, 7, 7), 1)
            t = self.f8.render("Territorio inicial", False, C_TEXTO2)
            s.blit(t, (mx, my - 12))
        self.botones = [Boton((ANCHO - 300, ALTO - 60, 260, 40), "EMPEZAR", lambda: self.nueva_partida(f["id"]), color=(60, 100, 60)),
                        Boton((40, ALTO - 60, 200, 40), "VOLVER", lambda: setattr(self, "estado", "menu"))]
        for b in self.botones:
            b.dibujar(s, self.f12, raton)

    def dibujar_ficha(self, s, ficha, rasgos, x, y, ancho, potencial=None, fid=None):
        etiquetas = [("periodo", "Periodo"), ("capital", "Capital"), ("poblacion", "Poblacion"), ("lengua", "Lengua"),
                     ("politica", "Gobierno"), ("economia", "Economia"), ("militar", "Guerra"), ("logro", "Logro"), ("curiosidad", "Sabias que")]
        for k, et in etiquetas:
            if k not in ficha:
                continue
            s.blit(self.f8.render(et.upper(), False, C_ACENTO), (x, y))
            y += 12
            y = dibujar_texto(s, self.f8, ficha[k], x, y, C_TEXTO, ancho=ancho, interlinea=3) + 4
        y += 4
        s.blit(self.f8.render("RASGOS DE JUEGO", False, C_ACENTO), (x, y))
        y += 12
        partes = []
        if rasgos.get("ataque"):
            partes.append(f"Ataque +{rasgos['ataque']}")
        if rasgos.get("defensa"):
            partes.append(f"Defensa +{rasgos['defensa']}")
        if rasgos.get("produccion"):
            partes.append(f"Produccion +{rasgos['produccion']}")
        partes.append(f"Terreno favorable: {rasgos.get('terreno')}")
        if rasgos.get("naval"):
            partes.append("Navegantes (rutas maritimas sin penalizacion)")
        if rasgos.get("movilidad"):
            partes.append("Caminos (mueve a 2 provincias)")
        y = dibujar_texto(s, self.f8, " - ".join(partes), x, y, C_TEXTO2, ancho=ancho, interlinea=3)
        if fid:
            from .facciones import POTENCIAL
            pot = POTENCIAL.get(fid, [1] * 5)
            y += 4
            s.blit(self.f8.render("POTENCIAL HISTORICO POR SIGLO", False, C_ACENTO), (x, y))
            y += 12
            for k, año in enumerate((1000, 1100, 1200, 1300, 1400)):
                s.blit(self.f8.render(str(año), False, C_TEXTO2), (x + k * 66, y))
                for b in range(7):
                    col = C_OK if b < pot[k] else (60, 56, 66)
                    pygame.draw.rect(s, col, (x + k * 66 + b * 8, y + 12, 6, 6))
            y += 26
        return y

    # ----- juego
    def dibujar_juego(self, raton):
        s = self.pantalla
        j = self.juego
        zoom = self.zoom()
        base = self.render.superficie(j, zoom, self.version_mapa)
        s.set_clip(MAPA_RECT)
        s.fill((18, 34, 66), MAPA_RECT)
        s.blit(base, (MAPA_RECT.x + self.desplazamiento[0], MAPA_RECT.y + self.desplazamiento[1]))
        self.dibujar_resaltes(s, zoom)
        self.dibujar_etiquetas(s, zoom, (MAPA_RECT.x + self.desplazamiento[0], MAPA_RECT.y + self.desplazamiento[1]))
        s.set_clip(None)
        self.dibujar_barra(raton)
        self.dibujar_panel(raton)
        if self.modal:
            self.dibujar_modal(raton)

    def celda_a_pantalla(self, c, r, zoom, origen):
        return origen[0] + c * zoom, origen[1] + r * zoom

    def dibujar_resaltes(self, s, zoom):
        j = self.juego
        origen = (MAPA_RECT.x + self.desplazamiento[0], MAPA_RECT.y + self.desplazamiento[1])
        parpadeo = (self.ticks // 250) % 2 == 0

        def contorno(i, color, grosor=2):
            p = j.mapa.provincias[i]
            for c, r in p["celdas"]:
                x, y = self.celda_a_pantalla(c, r, zoom, origen)
                for dc, dr, lado in ((1, 0, "d"), (-1, 0, "i"), (0, 1, "b"), (0, -1, "a")):
                    cc, rr = c + dc, r + dr
                    if not (0 <= cc < j.mapa.cols and 0 <= rr < j.mapa.rows) or j.mapa.prov_de_celda[rr][cc] != i:
                        if lado == "d":
                            pygame.draw.line(s, color, (x + zoom - 1, y), (x + zoom - 1, y + zoom - 1), grosor)
                        elif lado == "i":
                            pygame.draw.line(s, color, (x, y), (x, y + zoom - 1), grosor)
                        elif lado == "b":
                            pygame.draw.line(s, color, (x, y + zoom - 1), (x + zoom - 1, y + zoom - 1), grosor)
                        else:
                            pygame.draw.line(s, color, (x, y), (x + zoom - 1, y), grosor)

        if self.hover is not None and self.hover != self.seleccion:
            contorno(self.hover, (255, 255, 255), 1)
        if self.seleccion is not None:
            contorno(self.seleccion, C_ACENTO if parpadeo else (255, 255, 255), 2)
            f = j.jugador
            if j.fase == "ataque" and j.dueño[self.seleccion] == f and j.unidades[self.seleccion] >= 2:
                for v in j.mapa.provincias[self.seleccion]["vecinos"]:
                    if j.dueño[v] != f:
                        contorno(v, C_MAL, 2)
            elif j.fase == "movimiento" and j.dueño[self.seleccion] == f and not j.fortificado:
                for v in j.alcanzables_para_mover(f, self.seleccion):
                    contorno(v, C_AZUL, 2)
        # provincias del jugador: contorno tenue
        if j.jugador:
            for i in j.provincias_de(j.jugador):
                if i != self.seleccion:
                    contorno(i, aclarar(j.facciones[j.jugador].color, 1.5), 1)

    def dibujar_etiquetas(self, s, zoom, origen, completo=False):
        j = self.juego
        fuente = self.f8 if zoom < 8 else self.f10
        for i, p in enumerate(j.mapa.provincias):
            c, r = p["centro"]
            x, y = self.celda_a_pantalla(c, r, zoom, origen)
            x += zoom // 2
            y += zoom // 2
            if not completo and not MAPA_RECT.collidepoint(x, y):
                continue
            d = j.dueño[i]
            n = j.unidades[i]
            if zoom <= 3 and d is None and not completo:
                continue
            txt = str(n)
            t = fuente.render(txt, False, (255, 255, 255) if d else (40, 30, 20))
            w = t.get_width() + 6
            h = t.get_height() + 4
            col = (30, 26, 34) if d else (200, 190, 160)
            es_cap = d is not None and j.facciones[d].capital == p["id"]
            rect = pygame.Rect(x - w // 2, y - h // 2, w, h)
            pygame.draw.rect(s, col, rect)
            borde = C_ACENTO if es_cap else ((255, 255, 255) if d else (90, 80, 60))
            pygame.draw.rect(s, borde, rect, 1)
            s.blit(t, (rect.x + 3, rect.y + 2))
            if es_cap and zoom >= 6:
                # estrella / marca de capital
                pygame.draw.rect(s, C_ACENTO, (rect.x - 5, rect.y + h // 2 - 2, 4, 4))
            if zoom >= 12 or completo or (zoom >= 6 and i in (self.hover, self.seleccion)):
                nombre = p["nombre"] if zoom >= 12 or completo else p["nombre"][:18]
                tn = self.f8.render(nombre, False, (250, 250, 250))
                sombra = self.f8.render(nombre, False, (0, 0, 0))
                px, py = x - tn.get_width() // 2, rect.bottom + 2
                s.blit(sombra, (px + 1, py + 1))
                s.blit(tn, (px, py))

    def dibujar_barra(self, raton):
        s = self.pantalla
        j = self.juego
        pygame.draw.rect(s, C_PANEL, (0, 0, ANCHO, BARRA_H))
        pygame.draw.line(s, C_BORDE, (0, BARRA_H - 1), (ANCHO, BARRA_H - 1), 2)
        f = j.facciones[j.jugador]
        pygame.draw.rect(s, f.color, (10, 10, 20, 20))
        pygame.draw.rect(s, (10, 10, 10), (10, 10, 20, 20), 1)
        t = self.f10.render(f"{f.nombre[:26]}", False, C_TEXTO)
        s.blit(t, (38, 8))
        t = self.f8.render(f"{len(j.provincias_de(j.jugador))} prov. - {j.poder(j.jugador)} ejercitos", False, C_TEXTO2)
        s.blit(t, (38, 24))
        t = self.f16.render(f"AÑO {j.año}", False, C_ACENTO)
        s.blit(t, (400, 12))
        era = j.era_indice()
        t = self.f8.render(f"Era {era + 1}/5 - Turno {j.turno}/50", False, C_TEXTO2)
        s.blit(t, (560, 6))
        fases = {"refuerzo": f"REFUERZOS: {j.refuerzos}", "ataque": "ATAQUE", "movimiento": "MOVIMIENTO"}
        colf = {"refuerzo": C_OK, "ataque": C_MAL, "movimiento": C_AZUL}
        t = self.f10.render(fases[j.fase], False, colf[j.fase])
        s.blit(t, (560, 22))
        etiqueta = {"refuerzo": "SIGUIENTE >", "ataque": "SIGUIENTE >", "movimiento": "FIN DE TURNO >"}[j.fase]
        self.botones = [
            Boton((760, 6, 170, 28), etiqueta, self.siguiente_fase, color=(70, 90, 70)),
            Boton((940, 6, 90, 28), "ATLAS", lambda: setattr(self, "estado", "atlas")),
            Boton((1040, 6, 100, 28), "GUARDAR", self.guardar_partida),
            Boton((1150, 6, 60, 28), "?", self.abrir_ayuda_juego),
            Boton((1220, 6, 50, 28), "MENU", lambda: setattr(self, "estado", "menu")),
        ]
        for b in self.botones:
            b.dibujar(s, self.f8, raton)

    def abrir_ayuda_juego(self):
        self.estado_previo = "juego"
        self.estado = "ayuda"

    def dibujar_panel(self, raton):
        s = self.pantalla
        j = self.juego
        pygame.draw.rect(s, C_PANEL, PANEL_RECT)
        pygame.draw.line(s, C_BORDE, (PANEL_RECT.x, PANEL_RECT.y), (PANEL_RECT.x, ALTO), 2)
        y = PANEL_RECT.y + 8
        for k, (nombre, etiqueta) in enumerate([("provincia", "PROVINCIA"), ("faccion", "PUEBLO"), ("registro", "CRONICA")]):
            r = pygame.Rect(PANEL_RECT.x + 8 + k * 122, y, 118, 26)
            activo = self.pestaña == nombre
            pygame.draw.rect(s, C_PANEL2 if activo else oscurecer(C_PANEL2, 0.7), r)
            pygame.draw.rect(s, C_ACENTO if activo else C_BORDE, r, 2)
            t = self.f8.render(etiqueta, False, C_TEXTO if activo else C_TEXTO2)
            s.blit(t, (r.centerx - t.get_width() // 2, r.centery - t.get_height() // 2))
        contenido = pygame.Rect(PANEL_RECT.x + 8, y + 34, PANEL_W - 16, ALTO - y - 42)
        pygame.draw.rect(s, oscurecer(C_PANEL, 0.85), contenido)
        s.set_clip(contenido)
        x = contenido.x + 8
        yy = contenido.y + 8 - self.scroll_panel
        ancho = contenido.width - 16
        if self.pestaña == "provincia":
            yy = self.panel_provincia(s, x, yy, ancho)
        elif self.pestaña == "faccion":
            yy = self.panel_faccion(s, x, yy, ancho)
        else:
            yy = self.panel_registro(s, x, yy, ancho)
        s.set_clip(None)
        maximo = max(0, yy + self.scroll_panel - contenido.bottom + 10)
        if self.scroll_panel > maximo:
            self.scroll_panel = maximo
        if maximo > 0:
            t = self.f8.render("rueda: desplazar", False, C_TEXTO2)
            s.blit(t, (contenido.right - t.get_width() - 4, contenido.bottom - 12))

    def panel_provincia(self, s, x, y, ancho):
        j = self.juego
        i = self.hover if self.hover is not None else self.seleccion
        if i is None:
            y = dibujar_texto(s, self.f8, "Pasa el raton sobre una provincia para ver sus datos. Haz clic para seleccionarla.", x, y, C_TEXTO2, ancho=ancho)
            y += 8
            y = self.resumen_turno(s, x, y, ancho)
            return y
        p = j.mapa.provincias[i]
        y = dibujar_texto(s, self.f12, p["nombre"], x, y, C_ACENTO, ancho=ancho)
        y = dibujar_texto(s, self.f8, f"Terreno: {p['terreno']}", x, y, C_TEXTO2, ancho=ancho)
        y = dibujar_texto(s, self.f8, f"Pueblos: {p['pueblos']}", x, y, C_TEXTO, ancho=ancho)
        d = j.dueño[i]
        if d:
            f = j.facciones[d]
            pygame.draw.rect(s, f.color, (x, y + 1, 10, 10))
            y = dibujar_texto(s, self.f8, f"Dominio: {f.nombre}", x + 14, y, C_TEXTO, ancho=ancho - 14)
            if f.capital == p["id"]:
                y = dibujar_texto(s, self.f8, "CAPITAL (+2 defensa)", x, y, C_ACENTO, ancho=ancho)
        else:
            y = dibujar_texto(s, self.f8, "Dominio: pueblos locales independientes", x, y, C_TEXTO2, ancho=ancho)
        y = dibujar_texto(s, self.f10, f"Ejercitos: {j.unidades[i]}   Defensa +{j.bono_defensa(i)}", x, y, C_TEXTO, ancho=ancho)
        vecinos = [j.mapa.provincias[v]["nombre"] for v in p["vecinos"]]
        y = dibujar_texto(s, self.f8, "Vecinas: " + ", ".join(vecinos), x, y, C_TEXTO2, ancho=ancho)
        y += 8
        if self.seleccion is not None and self.seleccion != i and j.fase == "ataque" and j.puede_atacar(j.jugador, self.seleccion, i):
            y = dibujar_texto(s, self.f8, "Clic para ATACAR desde " + j.mapa.provincias[self.seleccion]["nombre"], x, y, C_MAL, ancho=ancho)
        y += 6
        y = self.resumen_turno(s, x, y, ancho)
        return y

    def resumen_turno(self, s, x, y, ancho):
        j = self.juego
        y = dibujar_texto(s, self.f8, "COMO JUGAR ESTE TURNO", x, y, C_ACENTO, ancho=ancho)
        textos = {
            "refuerzo": "Clic en tus provincias para colocar refuerzos (clic derecho: 5). Luego pulsa SIGUIENTE.",
            "ataque": "Clic en una provincia tuya (2+ ejercitos) y luego en una vecina enemiga (rojo). Cada ataque tira hasta 3 dados contra 2. Repite cuanto quieras.",
            "movimiento": "Mueve ejercitos una vez: clic en origen y luego en destino (azul). Clic izq: todos menos 1; clic der: la mitad. FIN DE TURNO para que jueguen los demas pueblos.",
        }
        y = dibujar_texto(s, self.f8, textos[j.fase], x, y, C_TEXTO2, ancho=ancho)
        y += 6
        y = dibujar_texto(s, self.f8, "Rueda: zoom - Arrastra con boton derecho: mover mapa - C: centrar - A: atlas - G: guardar - TAB: pestañas", x, y, C_TEXTO2, ancho=ancho)
        y += 8
        y = dibujar_texto(s, self.f8, "RANKING DE POTENCIAS", x, y, C_ACENTO, ancho=ancho)
        for k, f in enumerate(j.ranking()[:12]):
            pygame.draw.rect(s, f.color, (x, y + 1, 8, 8))
            col = C_TEXTO if f.es_jugador else C_TEXTO2
            y = dibujar_texto(s, self.f8, f"{k + 1:2d}. {f.nombre[:24]} ({len(j.provincias_de(f.id))})", x + 12, y, col, ancho=ancho - 12, interlinea=2)
        return y

    def panel_faccion(self, s, x, y, ancho):
        j = self.juego
        i = self.hover if self.hover is not None else self.seleccion
        fid = j.dueño[i] if i is not None and j.dueño[i] else j.jugador
        f = j.facciones[fid]
        pygame.draw.rect(s, f.color, (x, y + 2, 12, 12))
        y = dibujar_texto(s, self.f12, f.nombre, x + 16, y, C_TEXTO, ancho=ancho - 16)
        estado = f"Provincias: {len(j.provincias_de(fid))}  Ejercitos: {j.poder(fid)}  Refuerzos/turno: {j.calcular_refuerzos(fid)}"
        y = dibujar_texto(s, self.f8, estado, x, y, C_TEXTO2, ancho=ancho)
        if not f.viva:
            y = dibujar_texto(s, self.f8, f"Desaparecio en {f.eliminada_en}", x, y, C_MAL, ancho=ancho)
        y += 6
        y = self.dibujar_ficha(s, f.ficha, f.rasgos, x, y, ancho, fid=fid)
        return y

    def panel_registro(self, s, x, y, ancho):
        j = self.juego
        y = dibujar_texto(s, self.f8, "CRONICA DE LA PARTIDA (mas reciente arriba)", x, y, C_ACENTO, ancho=ancho)
        for año, texto, color in reversed(j.log[-60:]):
            y = dibujar_texto(s, self.f8, f"{año}: {texto}", x, y, color, ancho=ancho, interlinea=2)
            y += 3
        return y

    # ----- modales
    def dibujar_modal(self, raton):
        s = self.pantalla
        j = self.juego
        m = self.modal
        sombra = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
        sombra.fill((0, 0, 0, 120))
        s.blit(sombra, (0, 0))
        self.botones_modal = []
        if m["tipo"] == "dados":
            d = m["datos"]
            res = d["res"]
            rect = pygame.Rect(0, 0, 560, 330)
            rect.center = (MAPA_RECT.centerx, MAPA_RECT.centery)
            marco(s, rect, C_PANEL)
            po, pd = j.mapa.provincias[d["origen"]], j.mapa.provincias[d["destino"]]
            t = self.f12.render("COMBATE", False, C_ACENTO)
            s.blit(t, (rect.centerx - t.get_width() // 2, rect.y + 12))
            dibujar_texto(s, self.f8, f"{po['nombre']}  ->  {pd['nombre']}", rect.x + 20, rect.y + 36, C_TEXTO, ancho=rect.width - 40)
            # animación: 600 ms de dados girando
            girando = self.ticks - d["t0"] < 600
            rng = random.Random(self.ticks // 60)
            ya = rect.y + 90
            s.blit(self.f8.render("ATACANTE", False, C_MAL), (rect.x + 30, ya - 16))
            for k, v in enumerate(res.dados_ataque):
                val = rng.randint(1, 6) if girando else v
                dibujar_dado(s, rect.x + 30 + k * 60, ya, 48, val, (250, 220, 210))
            s.blit(self.f8.render("DEFENSOR", False, C_AZUL), (rect.x + 320, ya - 16))
            for k, v in enumerate(res.dados_defensa):
                val = rng.randint(1, 6) if girando else v
                dibujar_dado(s, rect.x + 320 + k * 60, ya, 48, val, (210, 225, 250))
            y = ya + 64
            if not girando:
                mods = []
                if res.mod_ataque:
                    mods.append(f"ataque {res.mod_ataque:+d}")
                if res.mod_defensa:
                    mods.append(f"defensa {res.mod_defensa:+d}")
                if mods:
                    y = dibujar_texto(s, self.f8, "Modificadores al dado mas alto: " + ", ".join(mods), rect.x + 20, y, C_TEXTO2, ancho=rect.width - 40)
                y = dibujar_texto(s, self.f10, f"Bajas: atacante -{res.perdidas_ataque}   defensor -{res.perdidas_defensa}", rect.x + 20, y + 4, C_TEXTO, ancho=rect.width - 40)
                if res.conquista:
                    y = dibujar_texto(s, self.f10, f"CONQUISTA de {pd['nombre']}", rect.x + 20, y + 4, C_OK, ancho=rect.width - 40)
                if res.eliminada:
                    nombre = j.facciones[res.eliminada].nombre
                    y = dibujar_texto(s, self.f8, f"{nombre} han sido eliminados de la historia.", rect.x + 20, y + 2, C_ACENTO, ancho=rect.width - 40)
                y = dibujar_texto(s, self.f8, f"Quedan: {j.unidades[d['origen']]} en origen, {j.unidades[d['destino']]} en destino", rect.x + 20, y + 4, C_TEXTO2, ancho=rect.width - 40)
                if d.get("puede_seguir"):
                    self.botones_modal.append(Boton((rect.x + 40, rect.bottom - 50, 220, 36), "ATACAR OTRA VEZ", self.atacar_de_nuevo, color=(110, 60, 60)))
                self.botones_modal.append(Boton((rect.right - 200, rect.bottom - 50, 160, 36), "CERRAR", self.cerrar_modal))
        else:
            d = m["datos"]
            ancho = 640
            # altura adaptada al texto
            n_lineas = len(envolver(self.f8, d["texto"], ancho - 40)) + sum(len(envolver(self.f8, "> " + l, ancho - 40)) for l in d.get("lineas", []))
            alto = 150 + n_lineas * 12 + (30 if m["tipo"] == "era" else 0)
            rect = pygame.Rect(0, 0, ancho, min(alto, MAPA_RECT.height - 20))
            rect.center = (MAPA_RECT.centerx, MAPA_RECT.centery)
            marco(s, rect, C_PANEL)
            titulo = f"{d['año']}: {d['titulo']}" if m["tipo"] == "evento" else d["titulo"]
            y = dibujar_texto(s, self.f12, titulo, rect.x + 20, rect.y + 16, C_ACENTO, ancho=rect.width - 40)
            fac = d.get("faccion")
            if fac and fac in j.facciones:
                f = j.facciones[fac]
                pygame.draw.rect(s, f.color, (rect.x + 20, y + 2, 10, 10))
                y = dibujar_texto(s, self.f8, f.nombre, rect.x + 34, y, C_TEXTO2, ancho=rect.width - 54)
            y += 6
            y = dibujar_texto(s, self.f8, d["texto"], rect.x + 20, y, C_TEXTO, ancho=rect.width - 40)
            y += 6
            for linea in d.get("lineas", []):
                y = dibujar_texto(s, self.f8, "> " + linea, rect.x + 20, y, C_OK if m["tipo"] == "evento" else C_TEXTO2, ancho=rect.width - 40)
            if m["tipo"] == "era":
                dibujar_texto(s, self.f8, "Mapa guardado en partidas/mapas. Pulsa A durante la partida para ver el Atlas.", rect.x + 20, rect.bottom - 76, C_TEXTO2, ancho=rect.width - 40)
            self.botones_modal.append(Boton((rect.right - 200, rect.bottom - 50, 160, 36), "CONTINUAR", self.cerrar_modal))
        for b in self.botones_modal:
            b.dibujar(s, self.f8, raton)

    # ----- atlas
    def dibujar_atlas(self):
        s = self.pantalla
        j = self.juego
        t = self.f16.render("ATLAS: UN MAPA POR ERA", False, C_ACENTO)
        s.blit(t, (30, 20))
        t = self.f8.render("Cada mapa muestra las fronteras al empezar el siglo. Los PNG se guardan en la carpeta partidas/mapas. Clic o ESC para volver.", False, C_TEXTO2)
        s.blit(t, (30, 50))
        años = sorted(j.mapas_era.keys())
        m = j.mapa
        zoom = 1
        w, h = m.cols * zoom, m.rows * zoom
        # dibujar cada mapa a 1 px por celda, con escala a 1.4
        esc = 1.35
        for k, año in enumerate(años[:6]):
            datos = j.mapas_era[año]
            surf = pygame.Surface((w, h))
            surf.fill((24, 44, 84))
            colores = {}
            for r in range(m.rows):
                for c in range(m.cols):
                    i = m.prov_de_celda[r][c]
                    if i < 0:
                        continue
                    d = datos["dueño"][i]
                    if d is None:
                        col = (150, 150, 120)
                    else:
                        col = datos["colores"].get(d, (200, 200, 200))
                    surf.set_at((c, r), col)
            surf = pygame.transform.scale(surf, (int(w * esc), int(h * esc)))
            col_x = 30 + (k % 3) * 410
            col_y = 80 + (k // 3) * 360
            s.blit(surf, (col_x, col_y))
            pygame.draw.rect(s, C_BORDE, (col_x, col_y, surf.get_width(), surf.get_height()), 2)
            t = self.f10.render(f"AÑO {año}", False, C_ACENTO)
            s.blit(t, (col_x + 4, col_y + 4))
            yy = col_y + 24
            for fid, nombre, nprov, pod in datos["resumen"][:6]:
                pygame.draw.rect(s, datos["colores"].get(fid, (200, 200, 200)), (col_x + 4, yy + 1, 7, 7))
                tt = self.f8.render(f"{nombre[:20]} {nprov}", False, (255, 255, 255))
                sombra = self.f8.render(f"{nombre[:20]} {nprov}", False, (0, 0, 0))
                s.blit(sombra, (col_x + 15, yy + 1))
                s.blit(tt, (col_x + 14, yy))
                yy += 11

    # ----- ayuda
    def dibujar_ayuda(self):
        s = self.pantalla
        t = self.f16.render("COMO SE JUEGA", False, C_ACENTO)
        s.blit(t, (40, 30))
        texto = [
            ("OBJETIVO", "Guiar a tu pueblo desde el año 1000 hasta 1490 (50 turnos de 10 años). Gana quien domine mas provincias al final, pero sobrevivir ya es un logro: muchos pueblos reales desaparecieron."),
            ("TURNO", "1) REFUERZOS: recibes ejercitos segun tus provincias, tu produccion y tu potencial historico del siglo. Colocalos con clic (clic derecho = 5).  2) ATAQUE: elige una provincia tuya con 2+ ejercitos y una vecina enemiga. El atacante tira hasta 3 dados, el defensor hasta 2; se comparan de mayor a menor y pierde el menor (empate favorece al defensor). 3) MOVIMIENTO: un solo movimiento entre provincias conectadas por tu territorio."),
            ("MODIFICADORES", "Cada pueblo tiene rasgos fieles a su historia: ataque, defensa, produccion, terreno favorable (+1 defensa), navegantes (atacan por rutas maritimas sin penalizacion) y caminos (mueven 2 provincias). Capitales +2, provincias natales +1, ultimo reducto +1 mas. Selva, montaña y altiplano neutrales +1."),
            ("HISTORIA", "64 eventos fechados cambian el mapa: colapsos (Tula, Wari, Cahokia), migraciones (mexicas, inuit, kalinago), sequias, fundaciones (Tenochtitlan, Cusco, Mayapan) y conquistas (incas, Triple Alianza). Si controlas a un pueblo que la historia condena, no desapareces: pierdes la mitad de tus ejercitos y puedes cambiar el destino."),
            ("POTENCIAL", "Cada siglo, cada pueblo tiene un potencial (0-7) que refleja su capacidad real: suma refuerzos, amplia el alcance de la IA y limita cuantas provincias administra bien (3 + 4 x potencial)."),
            ("MAPAS DE ERA", "En 1100, 1200, 1300, 1400 y 1490 se guarda el mapa con sus fronteras (Atlas, tecla A) y una imagen PNG en partidas/mapas."),
            ("TECLAS", "Rueda: zoom. Boton derecho o central arrastrando: mover mapa. C: centrar. ESPACIO/ENTER: siguiente fase. TAB: pestañas del panel. G: guardar. A: atlas. F11: pantalla completa. ESC: cancelar seleccion. M: menu."),
        ]
        y = 70
        for titulo, cuerpo in texto:
            s.blit(self.f10.render(titulo, False, C_ACENTO), (40, y))
            y += 18
            y = dibujar_texto(s, self.f8, cuerpo, 40, y, C_TEXTO, ancho=ANCHO - 80, interlinea=4) + 10
        t = self.f8.render("Pulsa cualquier tecla para volver", False, C_TEXTO2)
        s.blit(t, (40, ALTO - 30))

    # ----- final
    def dibujar_final(self, raton):
        s = self.pantalla
        j = self.juego
        f = j.facciones[j.jugador]
        titulo = "FIN DE LA PARTIDA: 1490" if j.resultado == "final" else "TU PUEBLO HA SIDO SOMETIDO"
        t = self.f16.render(titulo, False, C_ACENTO if j.resultado == "final" else C_MAL)
        s.blit(t, (40, 30))
        y = 70
        rank = j.ranking()
        pos = next((k + 1 for k, g in enumerate(rank) if g.id == f.id), None)
        if pos:
            y = dibujar_texto(s, self.f10, f"{f.nombre}: puesto {pos} de {len(rank)} pueblos vivos, {len(j.provincias_de(f.id))} provincias, {j.poder(f.id)} ejercitos, {f.conquistas} conquistas.", 40, y, C_TEXTO, ancho=ANCHO - 80)
        else:
            y = dibujar_texto(s, self.f10, f"{f.nombre} desaparecio en {f.eliminada_en}.", 40, y, C_MAL, ancho=ANCHO - 80)
        y += 10
        y = dibujar_texto(s, self.f10, "LO QUE DICE LA HISTORIA", 40, y, C_ACENTO)
        y = dibujar_texto(s, self.f8, f"Periodo real: {f.ficha['periodo']}. {f.ficha['logro']}. {f.ficha['curiosidad']}", 40, y, C_TEXTO, ancho=ANCHO - 80)
        y += 10
        y = dibujar_texto(s, self.f10, "RANKING FINAL 1490", 40, y, C_ACENTO)
        for k, g in enumerate(rank[:15]):
            pygame.draw.rect(s, g.color, (40, y + 1, 8, 8))
            y = dibujar_texto(s, self.f8, f"{k + 1:2d}. {g.nombre} - {len(j.provincias_de(g.id))} provincias, {j.poder(g.id)} ejercitos", 54, y, C_TEXTO if g.es_jugador else C_TEXTO2, ancho=ANCHO - 94, interlinea=4)
        y += 6
        muertas = [g for g in j.facciones.values() if g.aparecio and not g.viva]
        if muertas:
            y = dibujar_texto(s, self.f8, "Desaparecidos: " + ", ".join(f"{g.nombre} ({g.eliminada_en})" for g in muertas), 40, y, C_TEXTO2, ancho=ANCHO - 80)
        self.botones = [Boton((ANCHO - 520, ALTO - 60, 200, 40), "ATLAS", lambda: setattr(self, "estado", "atlas")),
                        Boton((ANCHO - 300, ALTO - 60, 260, 40), "MENU PRINCIPAL", lambda: setattr(self, "estado", "menu"))]
        for b in self.botones:
            b.dibujar(s, self.f12, raton)


def main():
    App().ejecutar()
