"""Rasteriza el contorno de América (Natural Earth 50m) a una rejilla de 1°.
Genera game/landmask.py con la máscara embebida (sin dependencias externas en runtime)."""
import json, sys
from shapely.geometry import shape, Point
from shapely.ops import unary_union
from shapely.prepared import prep

SRC = sys.argv[1]
LON0, LON1 = -168, -34   # columnas
LAT0, LAT1 = -56, 72     # filas (de norte a sur al dibujar)
STEP = 0.5
COLS = int((LON1 - LON0)/STEP)
ROWS = int((LAT1 - LAT0)/STEP)

gj = json.load(open(SRC))
polys = [shape(f["geometry"]) for f in gj["features"]]
land = prep(unary_union(polys))

mask = []
for r in range(ROWS):
    lat = LAT1 - (r + 0.5)*STEP
    row = []
    for c in range(COLS):
        lon = LON0 + (c + 0.5)*STEP
        pts = [(lon, lat), (lon-0.15, lat-0.15), (lon+0.15, lat-0.15), (lon-0.15, lat+0.15), (lon+0.15, lat+0.15)]
        hits = sum(1 for p in pts if land.contains(Point(*p)))
        row.append(1 if (hits >= 2 or land.contains(Point(lon, lat))) else 0)
    mask.append(row)

# Quitar Groenlandia / Eurasia extremo (fuera de alcance del juego): lon > -75 y lat > 59 -> Groenlandia
for r in range(ROWS):
    lat = LAT1 - (r + 0.5)*STEP
    for c in range(COLS):
        lon = LON0 + (c + 0.5)*STEP
        if lat > 59 and lon > -58:
            mask[r][c] = 0
        if lat > 65 and lon < -160:  # Siberia/Chukotka
            mask[r][c] = 0
        if lat < 30 and lon < -150:  # Hawái
            mask[r][c] = 0

with open("game/landmask.py", "w") as f:
    f.write("# Generado por tools/rasterize.py a partir de Natural Earth 50m (dominio público)\n")
    f.write(f"LON0, LAT1, COLS, ROWS, STEP = {LON0}, {LAT1}, {COLS}, {ROWS}, {STEP}\n")
    f.write("MASK = [\n")
    for row in mask:
        f.write('    "' + "".join("#" if v else "." for v in row) + '",\n')
    f.write("]\n")
print("celdas tierra:", sum(sum(r) for r in mask), "de", COLS*ROWS)
for row in mask[::4]:
    print("".join("#" if v else "." for v in row[::4]))
